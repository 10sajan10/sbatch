#!/usr/bin/env python3
"""Embedder registry for the sweep. One interface, four kinds:

  hf_clip    DFN5B-CLIP via transformers CLIPModel. Same calls as
             scripts/image_search_pipeline.py (vision_model -> visual_projection,
             text_model -> text_projection, fp16, L2-normalised) so vectors match
             the edge_v1/edge_v2 runs.
  open_clip  MobileCLIP2 (S0/S2/...) via open_clip, reparameterised for inference.
  jina_clip  jina-clip-v2 via trust_remote_code, same calls as edge_v3. Needs
             transformers==4.53.3 (see edge_v3/README.md) and is off by default.
  fake       Deterministic hash vectors. No GPU, no weights: for dry runs only.

Every embedder returns float32, L2-normalised rows.
"""

from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image


def _normalise(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.maximum(norms, 1e-12)


def default_device() -> str:
    if os.environ.get("SWEEP_DEVICE"):
        return os.environ["SWEEP_DEVICE"]
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


class Embedder:
    kind = "base"

    def __init__(self, name: str, spec: dict[str, Any], device: str):
        self.name = name
        self.spec = spec
        self.device = device
        self.dim: int | None = None
        self.text_token_limit = spec.get("text_token_limit")
        self.query_task = spec.get("query_task")

    def embed_images(self, images: list[Image.Image]) -> np.ndarray:
        raise NotImplementedError

    def embed_texts(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        raise NotImplementedError

    def count_text_tokens(self, texts: list[str]) -> list[int] | None:
        """Untruncated token counts (incl. special tokens), or None if unknown."""
        return None

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "kind": self.kind, "model_id": self.spec.get("model_id"),
                "device": self.device, "dimension": self.dim,
                "text_token_limit": self.text_token_limit, "query_task": self.query_task}


class HFClipEmbedder(Embedder):
    kind = "hf_clip"

    def __init__(self, name: str, spec: dict[str, Any], device: str, models_dir: Path):
        super().__init__(name, spec, device)
        import torch
        from transformers import AutoProcessor, CLIPModel

        model_dir = models_dir / spec["model_dir"]
        self.torch = torch
        self.processor = AutoProcessor.from_pretrained(model_dir, local_files_only=True)
        # Load in fp32, then cast: avoids the dtype=/torch_dtype= keyword change
        # between transformers 4.x and 5.x while giving the same fp16 weights.
        model = CLIPModel.from_pretrained(model_dir, local_files_only=True).eval()
        self.half = device.startswith("cuda")
        self.model = model.to(device=device, dtype=torch.float16 if self.half else torch.float32)
        self.dim = int(self.model.config.projection_dim)

    def _autocast(self):
        import contextlib

        if self.half:
            return self.torch.autocast("cuda", dtype=self.torch.float16)
        return contextlib.nullcontext()

    def embed_images(self, images: list[Image.Image]) -> np.ndarray:
        torch = self.torch
        inputs = self.processor(images=images, return_tensors="pt")
        pixels = inputs["pixel_values"].to(self.device, dtype=self.model.dtype)
        with torch.inference_mode(), self._autocast():
            output = self.model.vision_model(pixel_values=pixels)
            vectors = self.model.visual_projection(output.pooler_output)
            vectors = torch.nn.functional.normalize(vectors.float(), dim=-1)
        return vectors.cpu().numpy().astype(np.float32)

    def embed_texts(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        torch = self.torch
        inputs = self.processor(text=texts, padding=True, truncation=True, return_tensors="pt")
        with torch.inference_mode(), self._autocast():
            output = self.model.text_model(input_ids=inputs["input_ids"].to(self.device),
                                           attention_mask=inputs["attention_mask"].to(self.device))
            vectors = self.model.text_projection(output.pooler_output)
            vectors = torch.nn.functional.normalize(vectors.float(), dim=-1)
        return vectors.cpu().numpy().astype(np.float32)

    def count_text_tokens(self, texts: list[str]) -> list[int]:
        encoded = self.processor.tokenizer(texts, truncation=False)["input_ids"]
        return [len(ids) for ids in encoded]


class OpenClipEmbedder(Embedder):
    kind = "open_clip"

    def __init__(self, name: str, spec: dict[str, Any], device: str, models_dir: Path):
        super().__init__(name, spec, device)
        import open_clip
        import torch

        self.torch = torch
        # "checkpoint" (a local file, for air-gapped nodes) wins over the
        # "pretrained" tag, which open_clip resolves through the HF cache.
        checkpoint = spec.get("checkpoint")
        pretrained = str(models_dir / checkpoint) if checkpoint else spec.get("pretrained")
        model, _, preprocess = open_clip.create_model_and_transforms(
            spec["model_name"], pretrained=pretrained, device=device,
            cache_dir=os.environ.get("OPEN_CLIP_CACHE") or None,
        )
        model.eval()
        try:  # MobileCLIP's FastViT blocks must be fused for inference.
            from timm.utils import reparameterize_model

            model = reparameterize_model(model)
        except ImportError:
            pass
        self.model = model
        self.preprocess = preprocess
        self.tokenizer = open_clip.get_tokenizer(spec["model_name"])
        self.half = device.startswith("cuda")
        with torch.inference_mode():
            probe = self.model.encode_text(self.tokenizer(["probe"]).to(device))
        self.dim = int(probe.shape[-1])

    def _autocast(self):
        import contextlib

        if self.half:
            return self.torch.autocast("cuda", dtype=self.torch.float16)
        return contextlib.nullcontext()

    def embed_images(self, images: list[Image.Image]) -> np.ndarray:
        torch = self.torch
        batch = torch.stack([self.preprocess(image) for image in images]).to(self.device)
        with torch.inference_mode(), self._autocast():
            vectors = self.model.encode_image(batch)
            vectors = torch.nn.functional.normalize(vectors.float(), dim=-1)
        return vectors.cpu().numpy().astype(np.float32)

    def embed_texts(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        torch = self.torch
        tokens = self.tokenizer(texts).to(self.device)
        with torch.inference_mode(), self._autocast():
            vectors = self.model.encode_text(tokens)
            vectors = torch.nn.functional.normalize(vectors.float(), dim=-1)
        return vectors.cpu().numpy().astype(np.float32)

    def count_text_tokens(self, texts: list[str]) -> list[int] | None:
        tokenizer = self.tokenizer
        if hasattr(tokenizer, "encode"):  # open_clip SimpleTokenizer: no SOT/EOT
            return [len(tokenizer.encode(text)) + 2 for text in texts]
        inner = getattr(tokenizer, "tokenizer", None)  # open_clip HFTokenizer
        if inner is not None:
            return [len(ids) for ids in inner(texts, truncation=False)["input_ids"]]
        return None


class JinaClipEmbedder(Embedder):
    kind = "jina_clip"

    def __init__(self, name: str, spec: dict[str, Any], device: str, models_dir: Path):
        super().__init__(name, spec, device)
        import torch
        from transformers import AutoModel

        self.torch = torch
        self.model = AutoModel.from_pretrained(
            str(models_dir / spec["model_dir"]), trust_remote_code=True,
            use_text_flash_attn=bool(spec.get("use_text_flash_attn", False)),
            use_vision_xformers=bool(spec.get("use_vision_xformers", False)),
        ).eval().to(device)
        self.dim = int(spec.get("dimension", 1024))

    def embed_images(self, images: list[Image.Image]) -> np.ndarray:
        with self.torch.inference_mode():
            vectors = self.model.encode_image(images, truncate_dim=self.dim)
        return _normalise(vectors)

    def embed_texts(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        with self.torch.inference_mode():
            if query and self.query_task:
                vectors = self.model.encode_text(texts, task=self.query_task, truncate_dim=self.dim)
            else:  # captions: same call as edge_v3 (no task)
                vectors = self.model.encode_text(texts, truncate_dim=self.dim)
        return _normalise(vectors)

    def count_text_tokens(self, texts: list[str]) -> list[int] | None:
        tokenizer = getattr(self.model, "get_tokenizer", None)
        if tokenizer is None:
            return None
        encoded = tokenizer()(texts, truncation=False)["input_ids"]
        return [len(ids) for ids in encoded]


class FakeEmbedder(Embedder):
    """Hash-seeded vectors so the whole pipeline can be exercised without a GPU."""

    kind = "fake"

    def __init__(self, name: str, spec: dict[str, Any], device: str, models_dir: Path):
        super().__init__(name, spec, "cpu")
        self.dim = int(spec.get("dimension", 32))

    def _vector(self, payload: bytes) -> np.ndarray:
        seed = int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")
        return np.random.default_rng(seed).standard_normal(self.dim).astype(np.float32)

    def embed_images(self, images: list[Image.Image]) -> np.ndarray:
        return _normalise(np.stack([self._vector(image.tobytes()) for image in images]))

    def embed_texts(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        # Bag of hashed words, so texts that share words land close together.
        rows = []
        for text in texts:
            words = re.findall(r"\w+", text.lower())[: (self.text_token_limit or 10**9) - 2]
            vector = np.zeros(self.dim, dtype=np.float32)
            for word in words:
                vector += self._vector(word.encode("utf-8"))
            rows.append(vector if words else self._vector(b""))
        return _normalise(np.stack(rows))

    def count_text_tokens(self, texts: list[str]) -> list[int]:
        return [len(re.findall(r"\w+", text)) + 2 for text in texts]


KINDS = {
    "hf_clip": HFClipEmbedder,
    "open_clip": OpenClipEmbedder,
    "jina_clip": JinaClipEmbedder,
    "fake": FakeEmbedder,
}


def load_embedder(name: str, spec: dict[str, Any], *, models_dir: Path | None = None,
                  device: str | None = None) -> Embedder:
    kind = spec.get("kind")
    if kind not in KINDS:
        raise ValueError(f"Embedder {name!r} has unknown kind {kind!r}; expected one of {sorted(KINDS)}")
    models_dir = Path(models_dir or os.environ.get("MODELS_DIR") or Path.home() / "models")
    return KINDS[kind](name, spec, device or default_device(), models_dir)
