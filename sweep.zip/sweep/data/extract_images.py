#!/usr/bin/env python3
"""Materialize benchmark Parquet image columns as the JPEG tree used by ingestion."""

from __future__ import annotations

import argparse
import io
from pathlib import Path, PurePosixPath

import pyarrow.parquet as pq
from PIL import Image


DATASET_ID_COLUMNS = {
    "cloudbench": "image_id",
    "commonobjectsbench": "image_id",
    "firebench": "image_id",
    "inquire-small": "inat24_image_id",
    "sagebench": "image_id",
}


def relative_image_path(image_id: str) -> Path:
    relative = PurePosixPath(image_id)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe image ID: {image_id!r}")
    return Path(*relative.with_suffix(".jpg").parts)


def read_image_bytes(value: dict, parquet_path: Path) -> bytes:
    raw = value.get("bytes")
    if raw:
        return raw

    stored_path = value.get("path")
    if not stored_path:
        raise ValueError(f"Image has neither bytes nor path in {parquet_path}")

    for candidate in (
        parquet_path.parent / stored_path,
        parquet_path.parent.parent / stored_path,
    ):
        if candidate.is_file():
            return candidate.read_bytes()
    raise FileNotFoundError(f"Cannot resolve image path {stored_path!r}")


def extract_dataset(
    dataset_root: Path,
    output_root: Path,
    dataset: str,
    overwrite: bool,
) -> tuple[int, int]:
    id_column = DATASET_ID_COLUMNS[dataset]
    parquet_paths = sorted((dataset_root / dataset / "data").glob("*.parquet"))
    if not parquet_paths:
        raise FileNotFoundError(
            f"No Parquet shards found under {dataset_root / dataset / 'data'}"
        )

    written = skipped = 0
    seen: set[str] = set()
    for parquet_path in parquet_paths:
        parquet = pq.ParquetFile(parquet_path)
        for batch in parquet.iter_batches(
            batch_size=64,
            columns=[id_column, "image"],
        ):
            ids = batch.column(id_column).to_pylist()
            images = batch.column("image").to_pylist()
            for raw_id, image_value in zip(ids, images):
                image_id = str(raw_id)
                if image_id in seen:
                    continue
                seen.add(image_id)

                output_path = output_root / dataset / relative_image_path(image_id)
                if output_path.is_file() and not overwrite:
                    skipped += 1
                    continue

                image_bytes = read_image_bytes(image_value, parquet_path)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with Image.open(io.BytesIO(image_bytes)) as source:
                    source.convert("RGB").save(
                        output_path,
                        format="JPEG",
                        quality=95,
                    )
                written += 1
    return written, skipped


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset-root",
        type=Path,
        default=Path("benchmarking/datasets"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("benchmarking/image"),
    )
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=sorted(DATASET_ID_COLUMNS),
        default=list(DATASET_ID_COLUMNS),
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Rewrite JPEGs that already exist.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    total_written = total_skipped = 0
    for dataset in args.datasets:
        written, skipped = extract_dataset(
            args.dataset_root,
            args.output_root,
            dataset,
            args.overwrite,
        )
        total_written += written
        total_skipped += skipped
        print(f"{dataset}: written={written} existing={skipped}", flush=True)
    print(
        f"Finished: written={total_written} existing={total_skipped} "
        f"output={args.output_root}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
