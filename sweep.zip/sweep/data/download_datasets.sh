#!/usr/bin/env bash
# Download the five pinned benchmark datasets from Hugging Face.
#   HF_BIN=/path/to/hf BENCHMARK_DATA_DIR=/where/to sweep/data/download_datasets.sh
set -euo pipefail

HF_BIN="${HF_BIN:-hf}"
OUTPUT_DIR="${BENCHMARK_DATA_DIR:?set BENCHMARK_DATA_DIR to the download folder}"
MAX_WORKERS="${HF_MAX_WORKERS:-4}"

command -v "$HF_BIN" >/dev/null 2>&1 || [[ -x "$HF_BIN" ]] || {
  echo "Hugging Face CLI not found: $HF_BIN (set HF_BIN)" >&2; exit 1; }
mkdir -p "$OUTPUT_DIR"

download_dataset() {  # repo revision directory
  echo "Downloading $1@$2 -> ${OUTPUT_DIR}/$3"
  "$HF_BIN" download "$1" --repo-type dataset --revision "$2" \
    --local-dir "${OUTPUT_DIR}/$3" --max-workers "$MAX_WORKERS"
}

# Revisions pinned for reproducibility (same as the earlier edge runs).
download_dataset sagecontinuum/CloudBench              85eb9925499efde29b982780991d96f9321d1faf cloudbench
download_dataset sagecontinuum/CommonObjectsBench      445ae940b5676b3362b900a1a0e8a2a05636cbfb commonobjectsbench
download_dataset sagecontinuum/FireBench               be2f646c88843ce271410234aa885b375bf3cdbf firebench
download_dataset sagecontinuum/INQUIRE-Benchmark-small 0ca35458fc1c68f38fa5ad62c98b913ac0446cbd inquire-small
download_dataset sagecontinuum/SageBench               7428a2d887f48c4a217eee82c93a518d78734fd2 sagebench
echo "All benchmark datasets downloaded to ${OUTPUT_DIR}"
