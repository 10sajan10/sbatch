#!/usr/bin/env python3
"""Stage 1: caption every benchmark image with one captioner, for each caption variant.

Talks to any OpenAI-compatible chat endpoint, so the same script drives:
  - vLLM on a datacenter GPU (jobs/caption.slurm starts it for you),
  - vLLM on an edge device or workstation (port 8000),
  - Ollama, through its native /api/generate (captioners with "runtime": "ollama"),
    which lets thinking be switched off ("think": false) so reasoning models such as
    Gemma 4 spend the whole token cap on the caption. Point --endpoint at the
    Ollama host (http://HOST:11434); it can be another machine.

Requests are sent concurrently (--concurrency) so vLLM can batch them. Output is
one JSONL row per image per variant, appended as each finishes, so the job is
resumable: re-running skips rows already written.

Each row records completion_tokens and finish_reason. Those are the numbers the
paper's x-axis is built from (generated tokens drive VLM energy), so they are
kept for every caption, not just summarised.

    python3 sweep/caption.py --captioner gemma3-4b --endpoint http://127.0.0.1:8000/v1
    python3 sweep/caption.py --captioner gemma4-e2b --variants short long --max-images 20
"""

from __future__ import annotations

import argparse
import base64
import io
import json
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from pathlib import Path
from typing import Any

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import (  # noqa: E402
    ImageRecord,
    Layout,
    caption_set_name,
    default_dataset_dir,
    default_image_dir,
    iter_jsonl,
    load_config,
    load_records,
    pick,
    read_json,
    records_fingerprint,
    variant_max_tokens,
    variant_prompt,
    write_json_atomic,
)
# edge_v3's exact cleanup, vendored, so captions are post-processed the same way.
from sweep.textproc import clean_caption, trim_to_last_sentence  # noqa: E402


class ApiError(RuntimeError):
    def __init__(self, status: int, body: str):
        super().__init__(f"HTTP {status}: {body[:400]}")
        self.status = status


def http_json(url: str, payload: Any | None = None, timeout: float = 60) -> Any:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(
        url,
        data=data,
        method="POST" if data is not None else "GET",
        headers={"Content-Type": "application/json"} if data is not None else {},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read()
    except urllib.error.HTTPError as error:
        raise ApiError(error.code, error.read().decode("utf-8", "replace")) from error
    return json.loads(body) if body else None


def server_info(endpoint: str) -> dict[str, Any]:
    """Best-effort provenance: model list and server version, never fatal."""
    info: dict[str, Any] = {"endpoint": endpoint}
    base = endpoint.rstrip("/")
    root = base[:-3] if base.endswith("/v1") else base
    for key, url in (("models", f"{base}/models"), ("vllm_version", f"{root}/version"),
                     ("ollama_version", f"{root}/api/version")):
        try:
            info[key] = http_json(url, timeout=10)
        except Exception:  # noqa: BLE001 - provenance only
            continue
    return info


def image_data_uri(path: Path, max_edge: int) -> str:
    # Same preprocessing as edge_v1/edge_v3: RGB, longest edge <= max_edge, JPEG q90.
    with Image.open(path) as source:
        image = source.convert("RGB")
        image.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=90, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")


def image_base64(path: Path, max_edge: int) -> str:
    return image_data_uri(path, max_edge).split(",", 1)[1]


def ollama_base(endpoint: str) -> str:
    base = endpoint.rstrip("/")
    return base[:-3] if base.endswith("/v1") else base


def trim_keywords(text: str) -> str:
    """A cap-truncated keyword list ends mid-item; drop the partial item."""
    cut = text.rfind(",")
    return text[:cut].strip() if cut > 0 else text


def caption_one(
    record: ImageRecord,
    *,
    endpoint: str,
    model: str,
    prompt: str,
    max_tokens: int,
    kind: str,
    max_edge: int,
    temperature: float,
    seed: int,
    extra_body: dict[str, Any],
    timeout: float,
    retries: int,
    api: str = "openai",
    think: bool | None = None,
    num_ctx: int = 4096,
) -> dict[str, Any]:
    if api == "ollama":
        return caption_one_ollama(record, endpoint=endpoint, model=model, prompt=prompt,
                                  max_tokens=max_tokens, kind=kind, max_edge=max_edge,
                                  temperature=temperature, seed=seed, think=think,
                                  num_ctx=num_ctx, extra_body=extra_body, timeout=timeout,
                                  retries=retries)
    payload: dict[str, Any] = {
        "model": model,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": image_data_uri(record.image_path, max_edge)}},
                {"type": "text", "text": prompt},
            ],
        }],
        "max_tokens": max_tokens,
        "temperature": temperature,
        "seed": seed,
    }
    payload.update(extra_body)

    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        started = time.perf_counter()
        try:
            result = http_json(f"{endpoint.rstrip('/')}/chat/completions", payload, timeout)
            elapsed = time.perf_counter() - started
            choice = result["choices"][0]
            finish_reason = str(choice.get("finish_reason") or "")
            raw = (choice.get("message") or {}).get("content") or ""
            text = clean_caption(raw.strip())
            if not text:
                raise RuntimeError(f"empty caption (finish_reason={finish_reason!r})")
            if finish_reason == "length":
                text = trim_keywords(text) if kind == "keywords" else trim_to_last_sentence(text)
            usage = result.get("usage") or {}
            return {
                "dataset": record.dataset,
                "image_id": record.image_id,
                "caption": text,
                "words": len(text.split()),
                "completion_tokens": usage.get("completion_tokens"),
                "prompt_tokens": usage.get("prompt_tokens"),
                "finish_reason": finish_reason,
                # Wall time under concurrent load on the caption server. NOT a
                # per-image cost: cost is measured on the edge node, one request
                # at a time, by the profiling harness.
                "server_seconds": round(elapsed, 3),
            }
        except (ApiError, urllib.error.URLError, TimeoutError, OSError, KeyError,
                IndexError, ValueError, RuntimeError) as error:
            last_error = error
            if isinstance(error, ApiError) and 400 <= error.status < 500 and error.status != 429:
                break  # a bad request will not fix itself
            if attempt < retries:
                time.sleep(min(2 ** attempt, 20))
    raise RuntimeError(f"{type(last_error).__name__}: {last_error}")


def caption_one_ollama(
    record: ImageRecord, *, endpoint: str, model: str, prompt: str, max_tokens: int, kind: str,
    max_edge: int, temperature: float, seed: int, think: bool | None, num_ctx: int,
    extra_body: dict[str, Any], timeout: float, retries: int,
) -> dict[str, Any]:
    """Ollama native /api/generate: same image preprocessing, cap and trimming as the
    OpenAI path, with thinking switched off so the cap bounds the caption itself."""
    payload: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "images": [image_base64(record.image_path, max_edge)],
        "stream": False,
        "keep_alive": "30m",
        "options": {"num_predict": max_tokens, "temperature": temperature, "seed": seed,
                    "num_ctx": num_ctx},
    }
    if think is not None:
        payload["think"] = think
    payload.update(extra_body)
    url = f"{ollama_base(endpoint)}/api/generate"
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        started = time.perf_counter()
        try:
            result = http_json(url, payload, timeout)
            elapsed = time.perf_counter() - started
            finish_reason = str(result.get("done_reason") or "")
            text = clean_caption((result.get("response") or "").strip())
            if not text:
                raise RuntimeError(f"empty caption (done_reason={finish_reason!r})")
            if finish_reason == "length":
                text = trim_keywords(text) if kind == "keywords" else trim_to_last_sentence(text)
            return {
                "dataset": record.dataset,
                "image_id": record.image_id,
                "caption": text,
                "words": len(text.split()),
                "completion_tokens": result.get("eval_count"),
                "prompt_tokens": result.get("prompt_eval_count"),
                "finish_reason": finish_reason,
                "server_seconds": round(elapsed, 3),
            }
        except (ApiError, urllib.error.URLError, TimeoutError, OSError, KeyError,
                ValueError, RuntimeError) as error:
            last_error = error
            if isinstance(error, ApiError) and "think" in str(error).lower() and "think" in payload:
                payload.pop("think")  # model has no thinking switch: plain request instead
                continue
            if isinstance(error, ApiError) and 400 <= error.status < 500 and error.status != 429:
                break
            if attempt < retries:
                time.sleep(min(2 ** attempt, 20))
    raise RuntimeError(f"{type(last_error).__name__}: {last_error}")


def check_or_write_meta(path: Path, meta: dict[str, Any], force: bool) -> None:
    """Refuse to append to a caption file produced with different settings."""
    # The image set may grow (smoke test on one dataset, then all five); rows are
    # keyed by (dataset, image_id), so only generation settings are locked.
    locked = ("captioner", "model", "prompt", "max_tokens", "kind", "max_image_edge_pixels",
              "temperature", "seed", "extra_body", "api", "think")
    if path.exists() and not force:
        previous = read_json(path)
        changed = [key for key in locked if previous.get(key) != meta.get(key)]
        if changed:
            raise SystemExit(
                f"{path} was written with different settings ({', '.join(changed)}). "
                "Delete that caption set or pass --force to start a separate run."
            )
        meta = {**previous, "resumed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    write_json_atomic(path, meta)


def run_variant(args: argparse.Namespace, config: dict[str, Any], layout: Layout,
                records: list[ImageRecord], variant_name: str, variant: dict[str, Any]) -> int:
    captioner = config["captioners"][args.captioner]
    model = args.served_name or str(captioner["served_name"])
    api = args.api if args.api != "auto" else (
        "ollama" if captioner.get("runtime") == "ollama" else "openai")
    think = captioner.get("think", False) if api == "ollama" else None
    num_ctx = int(captioner.get("num_ctx", 4096))
    prompt = variant_prompt(config, variant)
    max_tokens = variant_max_tokens(config, variant)
    kind = str(variant.get("kind", "caption"))
    captioning = config["captioning"]
    out_path = layout.caption_file(args.captioner, variant_name)
    err_path = layout.caption_errors(args.captioner, variant_name)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    meta = {
        "caption_set": caption_set_name(args.captioner, variant_name),
        "captioner": args.captioner,
        "variant": variant_name,
        "model": model,
        "hf_id": captioner.get("hf_id"),
        "prompt": prompt,
        "max_tokens": max_tokens,
        "kind": kind,
        "target_words": variant.get("target_words"),
        "max_image_edge_pixels": int(captioning["max_image_edge_pixels"]),
        "temperature": float(captioning["temperature"]),
        "seed": int(captioning["seed"]),
        "extra_body": captioner.get("extra_body", {}),
        "api": api,
        "think": think,
        "num_ctx": num_ctx if api == "ollama" else None,
        "records_fingerprint": records_fingerprint(records),
        "record_count": len(records),
        "server": server_info(args.endpoint if api == "openai" else ollama_base(args.endpoint) + "/v1"),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    check_or_write_meta(layout.caption_meta(args.captioner, variant_name), meta, args.force)

    done = {(str(row["dataset"]), str(row["image_id"])) for row in iter_jsonl(out_path)}
    pending = [record for record in records if record.key not in done]
    if args.max_images:
        pending = pending[: args.max_images]
    print(f"[{meta['caption_set']}] max_tokens={max_tokens} done={len(done)} pending={len(pending)}",
          flush=True)
    if not pending:
        return 0

    call = dict(
        endpoint=args.endpoint, model=model, prompt=prompt, max_tokens=max_tokens, kind=kind,
        max_edge=int(captioning["max_image_edge_pixels"]),
        temperature=float(captioning["temperature"]), seed=int(captioning["seed"]),
        extra_body=dict(captioner.get("extra_body", {})), timeout=args.timeout, retries=args.retries,
        api=api, think=think, num_ctx=num_ctx,
    )
    written, failures = caption_batch(pending, call, args.concurrency, out_path, err_path, log_errors=False)
    if failures:
        # Most failures are timeouts under full load: retry them once, gently.
        print(f"  retrying {len(failures)} failed images at concurrency 4", flush=True)
        retry_call = dict(call, timeout=call["timeout"] * 2)
        more, failures = caption_batch(failures, retry_call, 4, out_path, err_path, log_errors=True)
        written += more
    print(f"[{meta['caption_set']}] finished: written={written} failed={len(failures)}"
          + (f" (listed in {err_path.name})" if failures else ""), flush=True)
    return 1 if failures else 0


def caption_batch(pending: list[ImageRecord], call: dict[str, Any], concurrency: int,
                  out_path: Path, err_path: Path, *, log_errors: bool) -> tuple[int, list[ImageRecord]]:
    """Caption `pending` with up to 2x`concurrency` requests in flight; returns (written, failed)."""
    written = 0
    failures: list[ImageRecord] = []
    started = time.time()
    queue = iter(pending)
    in_flight: dict[Future, ImageRecord] = {}
    with ThreadPoolExecutor(max_workers=concurrency) as pool, \
            out_path.open("a", encoding="utf-8") as output, \
            err_path.open("a", encoding="utf-8") as errors:

        def refill() -> None:
            while len(in_flight) < 2 * concurrency:
                record = next(queue, None)
                if record is None:
                    return
                in_flight[pool.submit(caption_one, record, **call)] = record

        refill()
        while in_flight:
            finished, _ = wait(in_flight, return_when=FIRST_COMPLETED)
            for future in finished:
                record = in_flight.pop(future)
                try:
                    row = future.result()
                except Exception as error:  # noqa: BLE001 - one bad image must not end the run
                    failures.append(record)
                    if log_errors:
                        errors.write(json.dumps({"dataset": record.dataset, "image_id": record.image_id,
                                                 "error": str(error),
                                                 "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}) + "\n")
                        errors.flush()
                    continue
                output.write(json.dumps(row, ensure_ascii=False) + "\n")
                output.flush()
                written += 1
                total = written + len(failures)
                if total % 200 == 0 or total == len(pending):
                    rate = total / max(time.time() - started, 1e-6)
                    left = (len(pending) - total) / rate if rate else 0.0
                    print(f"  {total}/{len(pending)} ok={written} failed={len(failures)} "
                          f"({rate * 60:.0f}/min, ~{left / 60:.0f} min left)", flush=True)
            refill()
    return written, failures


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--root", type=Path, help="Sweep output root (default: $SWEEP_ROOT or sweep/runs).")
    parser.add_argument("--captioner", required=True)
    parser.add_argument("--variants", nargs="+", help="Default: every enabled variant.")
    parser.add_argument("--endpoint", default="http://127.0.0.1:8000/v1",
                        help="Server base URL: OpenAI-compatible ending in /v1, or the Ollama host "
                             "(http://HOST:11434) for runtime=ollama captioners.")
    parser.add_argument("--api", choices=("auto", "openai", "ollama"), default="auto",
                        help="auto: Ollama native API for captioners with runtime=ollama, else OpenAI.")
    parser.add_argument("--served-name", help="Override the model name sent to the endpoint.")
    parser.add_argument("--concurrency", type=int, default=32)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--dataset-dir", type=Path, default=None)
    parser.add_argument("--image-dir", type=Path, default=None)
    parser.add_argument("--datasets", nargs="+", help="Subset of the config's datasets.")
    parser.add_argument("--max-images", type=int, default=0, help="Smoke-test knob; 0 = all.")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite a caption set's settings record instead of refusing.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    if args.captioner not in config["captioners"]:
        raise SystemExit(f"Unknown captioner {args.captioner!r}; known: {sorted(config['captioners'])}")
    layout = Layout(args.root)
    datasets = args.datasets or config["datasets"]
    records = load_records(args.dataset_dir or default_dataset_dir(),
                           args.image_dir or default_image_dir(), datasets)
    print(f"{len(records)} images across {len(datasets)} datasets; output under {layout.root}", flush=True)

    status = 0
    for name, variant in pick(config["caption_variants"], args.variants, "caption variant").items():
        status |= run_variant(args, config, layout, records, name, variant)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
