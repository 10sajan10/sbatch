# Sweep runtime for the Jetson AGX Thor: the edge_v3 image (transformers 4.53.3,
# timm, peft, flash-attn build) plus open_clip for MobileCLIP2 and the vector
# database clients used by load_index.py. Build while the node is connected:
#
#   docker build -f sweep/docker/Dockerfile.thor -t localhost/imsearch-sweep:dev .
#
# Then run stages air-gapped with sweep/jobs/thor_run.sh.
FROM localhost/imsearch-edge-v3:dev

RUN pip install --no-cache-dir \
        "open-clip-torch==3.3.0" \
        "timm==1.0.30" \
        "qdrant-client==1.19.1" \
        "pymilvus==3.0.2" \
        "milvus-lite==3.2.1"

ENV HF_HOME=/models/hf-cache \
    HF_HUB_OFFLINE=1 \
    TRANSFORMERS_OFFLINE=1

WORKDIR /work
