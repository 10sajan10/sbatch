#!/usr/bin/env python3
"""Stage 5 (on the edge node): load a packed NPZ into a vector database and measure it.

Databases are not converted file-to-file. Qdrant segments, a Milvus Lite data
directory, and Weaviate's LSM shards are each engine-specific (and some are
architecture-specific), so the portable NPZ is the source of truth and each
engine is bulk-loaded from it:

    qdrant    server (--url http://127.0.0.1:6333) or embedded (--path DIR), via qdrant-client
    milvus    Milvus Lite (--path DIR) or a Milvus server (--url http://host:19530), via pymilvus
    weaviate  server (--url http://127.0.0.1:8080), plain REST like the rest of this repo

Every backend gets the same collection shape as edge_v3: named vectors
"image" and "caption" (cosine, HNSW with the parameters you pass), payload
dataset/image_id/caption/image_path, and the edge_v3 point IDs.

Retrieval QUALITY never depends on the database: evaluate_npz.py scores the NPZ
with exact search. What this script measures is the database's COST on the
device, plus how far its approximate (HNSW) results drift from exact:

  load seconds and points/s, on-disk size (embedded modes), and a probe of
  --probe random queries per dataset: client-side latency p50/p95 and
  recall@k of the database's top-k against exact top-k.

    python3 sweep/load_index.py --npz runs/npz/gemma3-4b__short__dfn5b.npz \
        --backend milvus --path runs/db/milvus-short --probe 200
    python3 sweep/load_index.py --npz ... --backend qdrant --url http://127.0.0.1:6333
"""

from __future__ import annotations

import argparse
import json
import platform
import shutil
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Iterator

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import POINT_ID_NAMESPACE, Layout, package_versions, write_json_atomic  # noqa: E402


def load_npz(path: Path) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    with np.load(path) as archive:
        metadata = json.loads(bytes(archive["metadata"]).decode("utf-8"))
        return metadata, archive["image_vectors"].astype(np.float32), archive["caption_vectors"].astype(np.float32)


def point_id(record: dict[str, Any]) -> str:
    return str(uuid.uuid5(POINT_ID_NAMESPACE, f"{record['dataset']}/{record['image_id']}"))


def batches(count: int, size: int) -> Iterator[range]:
    for start in range(0, count, size):
        yield range(start, min(start + size, count))


def directory_bytes(path: Path) -> int | None:
    if not path.exists():
        return None
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


# ------------------------------------------------------------------ backends ---

class Backend:
    name = "base"
    note: str | None = None

    def __init__(self, args: argparse.Namespace, dim: int):
        self.args = args
        self.dim = dim
        self.collection = args.collection

    def create(self) -> None: ...
    def insert(self, rows: list[dict[str, Any]]) -> None: ...
    def finalize(self) -> None: ...
    def search(self, vector: np.ndarray, using: str, dataset: str, k: int) -> list[str]: ...
    def count(self) -> int: ...
    def close(self) -> None: ...


class QdrantBackend(Backend):
    name = "qdrant"

    def __init__(self, args: argparse.Namespace, dim: int):
        super().__init__(args, dim)
        from qdrant_client import QdrantClient, models

        self.models = models
        self.client = QdrantClient(path=str(args.path)) if args.path else QdrantClient(url=args.url, timeout=120)
        if args.path:
            import warnings

            # qdrant-client's embedded mode is a pure-Python brute-force scan:
            # fine for checking the data, NOT a stand-in for Qdrant or Qdrant
            # Edge latency. Say so in the report instead of warning per query.
            warnings.filterwarnings("ignore", message="Local mode performs exact")
            self.note = ("qdrant-client local mode: exact brute-force search in Python; HNSW settings "
                         "are ignored. Use a Qdrant server (--url) for latency comparisons.")

    def create(self) -> None:
        models = self.models
        if self.client.collection_exists(self.collection):
            if not self.args.recreate:
                raise SystemExit(f"Collection {self.collection} exists; pass --recreate to replace it")
            self.client.delete_collection(self.collection)
        hnsw = models.HnswConfigDiff(m=self.args.hnsw_m, ef_construct=self.args.hnsw_ef_construction)
        self.client.create_collection(
            self.collection,
            vectors_config={name: models.VectorParams(size=self.dim, distance=models.Distance.COSINE,
                                                      hnsw_config=hnsw)
                            for name in ("image", "caption")},
        )
        if not self.args.path:  # embedded mode has no payload indexes
            self.client.create_payload_index(self.collection, "dataset",
                                             field_schema=models.PayloadSchemaType.KEYWORD)

    def insert(self, rows: list[dict[str, Any]]) -> None:
        models = self.models
        self.client.upsert(self.collection, wait=True, points=[
            models.PointStruct(id=row["id"], vector={"image": row["image_vector"],
                                                      "caption": row["caption_vector"]},
                               payload={key: row[key] for key in ("dataset", "image_id", "caption", "image_path")})
            for row in rows
        ])

    def search(self, vector: np.ndarray, using: str, dataset: str, k: int) -> list[str]:
        models = self.models
        result = self.client.query_points(
            self.collection, query=vector.tolist(), using=using, limit=k, with_payload=["image_id"],
            query_filter=models.Filter(must=[models.FieldCondition(key="dataset",
                                                                   match=models.MatchValue(value=dataset))]),
            search_params=models.SearchParams(hnsw_ef=self.args.ef_search),
        )
        return [str(point.payload["image_id"]) for point in result.points]

    def count(self) -> int:
        return int(self.client.count(self.collection, exact=True).count)

    def close(self) -> None:
        self.client.close()


class MilvusBackend(Backend):
    name = "milvus"

    def __init__(self, args: argparse.Namespace, dim: int):
        super().__init__(args, dim)
        from pymilvus import DataType, MilvusClient

        self.DataType = DataType
        uri = str(args.path) if args.path else args.url
        if args.path:
            args.path.parent.mkdir(parents=True, exist_ok=True)
        self.client = MilvusClient(uri)

    def create(self) -> None:
        DataType = self.DataType
        if self.client.has_collection(self.collection):
            if not self.args.recreate:
                raise SystemExit(f"Collection {self.collection} exists; pass --recreate to replace it")
            self.client.drop_collection(self.collection)
        schema = self.client.create_schema(auto_id=False, enable_dynamic_field=False)
        schema.add_field("id", DataType.VARCHAR, is_primary=True, max_length=36)
        schema.add_field("dataset", DataType.VARCHAR, max_length=64)
        schema.add_field("image_id", DataType.VARCHAR, max_length=512)
        schema.add_field("image_path", DataType.VARCHAR, max_length=1024)
        schema.add_field("caption", DataType.VARCHAR, max_length=65535)
        schema.add_field("image", DataType.FLOAT_VECTOR, dim=self.dim)
        schema.add_field("caption_vector", DataType.FLOAT_VECTOR, dim=self.dim)
        index = self.client.prepare_index_params()
        for field in ("image", "caption_vector"):
            index.add_index(field_name=field, index_type=self.args.milvus_index, metric_type="COSINE",
                            params={"M": self.args.hnsw_m, "efConstruction": self.args.hnsw_ef_construction}
                            if self.args.milvus_index == "HNSW" else {})
        self.client.create_collection(self.collection, schema=schema, index_params=index)

    def insert(self, rows: list[dict[str, Any]]) -> None:
        self.client.insert(self.collection, [
            {"id": row["id"], "dataset": row["dataset"], "image_id": row["image_id"],
             "image_path": row["image_path"], "caption": row["caption"][:60000],
             "image": row["image_vector"], "caption_vector": row["caption_vector"]}
            for row in rows
        ])

    def finalize(self) -> None:
        if hasattr(self.client, "flush"):
            self.client.flush(self.collection)
        self.client.load_collection(self.collection)

    def search(self, vector: np.ndarray, using: str, dataset: str, k: int) -> list[str]:
        field = "image" if using == "image" else "caption_vector"
        params = {"ef": max(self.args.ef_search, k)} if self.args.milvus_index == "HNSW" else {}
        hits = self.client.search(self.collection, data=[vector.tolist()], anns_field=field, limit=k,
                                  filter=f'dataset == "{dataset}"', output_fields=["image_id"],
                                  search_params={"metric_type": "COSINE", "params": params})
        return [str(hit["entity"]["image_id"]) for hit in hits[0]]

    def count(self) -> int:
        return int(self.client.get_collection_stats(self.collection)["row_count"])

    def close(self) -> None:
        self.client.close()


class WeaviateBackend(Backend):
    """Plain REST/GraphQL, the same way scripts/image_search_pipeline.py talks to Weaviate."""

    name = "weaviate"

    def __init__(self, args: argparse.Namespace, dim: int):
        super().__init__(args, dim)
        self.url = args.url.rstrip("/")
        # Weaviate class names must start with an upper-case letter.
        self.collection = self.collection[:1].upper() + self.collection[1:]

    def request(self, method: str, path: str, payload: Any = None, timeout: float = 180) -> Any:
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        request = urllib.request.Request(f"{self.url}{path}", data=data, method=method,
                                         headers={"Content-Type": "application/json"} if data else {})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read()
        except urllib.error.HTTPError as error:
            raise RuntimeError(f"Weaviate {method} {path}: HTTP {error.code} "
                               f"{error.read().decode('utf-8', 'replace')[:400]}") from error
        return json.loads(body) if body else None

    def create(self) -> None:
        try:
            self.request("GET", f"/v1/schema/{self.collection}")
            exists = True
        except RuntimeError as error:
            if "HTTP 404" not in str(error):
                raise
            exists = False
        if exists:
            if not self.args.recreate:
                raise SystemExit(f"Class {self.collection} exists; pass --recreate to replace it")
            self.request("DELETE", f"/v1/schema/{self.collection}")
        index = {"distance": "cosine", "efConstruction": self.args.hnsw_ef_construction,
                 "maxConnections": self.args.hnsw_m, "ef": self.args.ef_search}
        text = {"dataType": ["text"], "tokenization": "field", "indexSearchable": False}
        self.request("POST", "/v1/schema", {
            "class": self.collection,
            "properties": [
                {"name": "dataset", **text, "indexFilterable": True},
                {"name": "image_id", **text, "indexFilterable": True},
                {"name": "image_path", **text, "indexFilterable": False},
                {"name": "caption", "dataType": ["text"], "tokenization": "word",
                 "indexSearchable": True, "indexFilterable": False},
            ],
            "vectorConfig": {name: {"vectorizer": {"none": {}}, "vectorIndexType": "hnsw",
                                    "vectorIndexConfig": index} for name in ("image", "caption")},
        })

    def insert(self, rows: list[dict[str, Any]]) -> None:
        response = self.request("POST", "/v1/batch/objects", {"objects": [
            {"class": self.collection, "id": row["id"],
             "properties": {key: row[key] for key in ("dataset", "image_id", "caption", "image_path")},
             "vectors": {"image": row["image_vector"], "caption": row["caption_vector"]}}
            for row in rows
        ]})
        failed = [item for item in response or [] if item.get("result", {}).get("errors")]
        if failed:
            raise RuntimeError(f"Weaviate rejected {len(failed)} objects: {failed[0]['result']['errors']}")

    def search(self, vector: np.ndarray, using: str, dataset: str, k: int) -> list[str]:
        graphql = (
            f'{{ Get {{ {self.collection}(nearVector: {{vector: {json.dumps(vector.tolist())}, '
            f'targetVectors: ["{using}"]}} '
            f'where: {{path: ["dataset"], operator: Equal, valueText: {json.dumps(dataset)}}} '
            f'limit: {k}) {{ image_id }} }} }}'
        )
        result = self.request("POST", "/v1/graphql", {"query": graphql})
        if result.get("errors"):
            raise RuntimeError(json.dumps(result["errors"])[:400])
        return [str(row["image_id"]) for row in result["data"]["Get"].get(self.collection) or []]

    def count(self) -> int:
        result = self.request("POST", "/v1/graphql",
                              {"query": f"{{ Aggregate {{ {self.collection} {{ meta {{ count }} }} }} }}"})
        return int(result["data"]["Aggregate"][self.collection][0]["meta"]["count"])


BACKENDS = {"qdrant": QdrantBackend, "milvus": MilvusBackend, "weaviate": WeaviateBackend}


# --------------------------------------------------------------------- main ---

def probe(backend: Backend, metadata: dict[str, Any], image_vectors: np.ndarray,
          caption_vectors: np.ndarray, per_dataset: int, k: int, seed: int) -> dict[str, Any]:
    """Time `per_dataset` searches per dataset against the image leg and compare to exact top-k.

    Query vectors are stored caption vectors of randomly chosen images: they live
    in the text side of the shared space like real text queries, so the HNSW
    search sees realistic cross-modal queries without loading a text encoder.
    """
    rng = np.random.default_rng(seed)
    records = metadata["records"]
    by_dataset: dict[str, list[int]] = {}
    for position, record in enumerate(records):
        by_dataset.setdefault(str(record["dataset"]), []).append(position)
    latencies, recalls = [], []
    for dataset, positions in sorted(by_dataset.items()):
        positions_array = np.asarray(positions)
        matrix = image_vectors[positions_array]
        ids = [str(records[p]["image_id"]) for p in positions]
        chosen = rng.choice(len(positions), size=min(per_dataset, len(positions)), replace=False)
        for row in chosen:
            query = caption_vectors[positions_array[row]]
            started = time.perf_counter()
            found = backend.search(query, "image", dataset, k)
            latencies.append((time.perf_counter() - started) * 1000.0)
            exact = {ids[i] for i in np.argsort(-(matrix @ query), kind="stable")[:k]}
            recalls.append(len(exact & set(found)) / max(min(k, len(ids)), 1))
    array = np.asarray(latencies)
    return {
        "queries": len(latencies), "k": k,
        "latency_ms_p50": round(float(np.percentile(array, 50)), 3),
        "latency_ms_p95": round(float(np.percentile(array, 95)), 3),
        "latency_ms_mean": round(float(array.mean()), 3),
        "recall_at_k_vs_exact": round(float(np.mean(recalls)), 4),
        "note": "client-side wall time per query, single client, includes client/serialisation overhead",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--npz", type=Path, required=True)
    parser.add_argument("--backend", choices=sorted(BACKENDS), required=True)
    parser.add_argument("--url", help="Server URL (qdrant/milvus/weaviate).")
    parser.add_argument("--path", type=Path, help="Embedded data directory (qdrant local mode, Milvus Lite).")
    parser.add_argument("--collection", help="Default: derived from the NPZ config name.")
    parser.add_argument("--recreate", action="store_true", help="Drop an existing collection first.")
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--hnsw-m", type=int, default=16)
    parser.add_argument("--hnsw-ef-construction", type=int, default=128)
    parser.add_argument("--ef-search", type=int, default=64)
    parser.add_argument("--milvus-index", choices=["HNSW", "FLAT"], default="HNSW")
    parser.add_argument("--probe", type=int, default=100, help="Probe queries per dataset (0 = skip).")
    parser.add_argument("--k", type=int, default=25)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--report", type=Path, help="Default: <root>/db/<backend>__<config>.json")
    parser.add_argument("--root", type=Path)
    args = parser.parse_args()
    if not (args.url or args.path):
        parser.error("pass --url (server) or --path (embedded)")
    if args.backend == "weaviate" and not args.url:
        parser.error("weaviate needs --url")
    if args.backend == "milvus" and args.path and args.path.suffix != ".db":
        # pymilvus only treats a local URI as Milvus Lite when it ends in .db
        # (with Milvus Lite 3.x that ".db" is a directory, not a single file).
        args.path = args.path.with_name(args.path.name + ".db")

    metadata, image_vectors, caption_vectors = load_npz(args.npz)
    config = str(metadata.get("config_name") or args.npz.stem)
    args.collection = args.collection or "sweep_" + config.replace("-", "_").replace(".", "_")
    if args.path and args.recreate and args.backend == "milvus" and args.path.exists():
        shutil.rmtree(args.path)  # Milvus Lite keeps one collection set per data directory
    backend = BACKENDS[args.backend](args, int(image_vectors.shape[1]))

    records = metadata["records"]
    backend.create()
    started = time.perf_counter()
    for chunk in batches(len(records), args.batch_size):
        backend.insert([{**records[i], "id": point_id(records[i]),
                         "image_vector": image_vectors[i].tolist(),
                         "caption_vector": caption_vectors[i].tolist()}
                        for i in chunk])
    backend.finalize()
    load_seconds = time.perf_counter() - started
    stored = backend.count()
    print(f"[{args.backend}] loaded {stored}/{len(records)} points into {backend.collection} "
          f"in {load_seconds:.1f}s ({len(records) / max(load_seconds, 1e-6):.0f} points/s)", flush=True)
    if backend.note:
        print(f"[{args.backend}] NOTE: {backend.note}", flush=True)

    report: dict[str, Any] = {
        "backend": args.backend,
        "target": str(args.path) if args.path else args.url,
        "collection": backend.collection,
        "npz": str(args.npz),
        "config_name": config,
        "points": len(records),
        "points_stored": stored,
        "vector_dimension": int(image_vectors.shape[1]),
        "hnsw": {"m": args.hnsw_m, "ef_construction": args.hnsw_ef_construction, "ef_search": args.ef_search,
                 "milvus_index": args.milvus_index if args.backend == "milvus" else None},
        "load_seconds": round(load_seconds, 2),
        "points_per_second": round(len(records) / max(load_seconds, 1e-6), 1),
        "disk_bytes": directory_bytes(args.path) if args.path else None,
        "note": backend.note,
        "host": {"machine": platform.machine(), "node": platform.node()},
        "versions": package_versions("qdrant-client", "pymilvus", "milvus-lite", "numpy"),
        "measured_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    if args.probe:
        report["probe"] = probe(backend, metadata, image_vectors, caption_vectors, args.probe, args.k, args.seed)
        result = report["probe"]
        print(f"[{args.backend}] probe: p50={result['latency_ms_p50']}ms p95={result['latency_ms_p95']}ms "
              f"recall@{args.k} vs exact={result['recall_at_k_vs_exact']}", flush=True)
    backend.close()

    report_path = args.report or Layout(args.root).db_dir / f"{args.backend}__{config}.json"
    write_json_atomic(report_path, report)
    print(f"report: {report_path}")
    return 0 if stored == len(records) else 1


if __name__ == "__main__":
    raise SystemExit(main())
