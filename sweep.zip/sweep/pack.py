#!/usr/bin/env python3
"""Stage 3: pack each (captioner, variant, embedder) into one portable NPZ.

The NPZ uses the same layout as scripts/export_edge_v2_npz.py and
scripts/export_edge_v3_npz.py (format_version 1): a UTF-8 JSON `metadata` blob
with one record per image (dataset, image_id, caption, image_path), plus
`image_vectors` and `caption_vectors` as float32 matrices in record order. Extra
metadata keys describe where the vectors came from; readers of the original
format ignore them. Unlike those exporters, the vector width is whatever the
embedder produces (512 for MobileCLIP2-S2, 1024 for DFN5B).

This file is the hand-off point: evaluate_npz.py scores it, and load_index.py
loads it into Qdrant, Milvus (Lite), or Weaviate.

    python3 sweep/pack.py                     # everything that is ready
    python3 sweep/pack.py --embedders dfn5b --variants short long
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import (  # noqa: E402
    PORTABLE_INDEX_VERSION,
    Layout,
    caption_set_name,
    config_name,
    default_dataset_dir,
    default_image_dir,
    load_caption_rows,
    load_config,
    load_records,
    meta_path,
    pick,
    read_json,
    records_fingerprint,
    sha256_file,
    write_json_atomic,
)


def caption_stats(rows: list[dict[str, Any]]) -> dict[str, Any]:
    words = [int(row.get("words") or len(str(row["caption"]).split())) for row in rows]
    tokens = [int(row["completion_tokens"]) for row in rows if row.get("completion_tokens") is not None]
    reasons = Counter(str(row.get("finish_reason") or "") for row in rows)
    stats: dict[str, Any] = {
        "words_mean": round(float(np.mean(words)), 2),
        "words_p50": int(np.percentile(words, 50)),
        "words_p95": int(np.percentile(words, 95)),
        "finish_reasons": dict(sorted(reasons.items())),
    }
    if tokens:
        stats.update({
            "completion_tokens_mean": round(float(np.mean(tokens)), 2),
            "completion_tokens_p50": int(np.percentile(tokens, 50)),
            "completion_tokens_p95": int(np.percentile(tokens, 95)),
            "completion_tokens_total": int(np.sum(tokens)),
        })
    return stats


def pack_one(config: dict[str, Any], layout: Layout, records: list, fingerprint: str,
             captioner: str, variant: str, embedder: str, force: bool) -> str:
    name = config_name(captioner, variant, embedder)
    image_path = layout.image_vectors(embedder)
    caption_path = layout.caption_vectors(embedder, captioner, variant)
    output = layout.npz(captioner, variant, embedder)
    manifest_path = output.with_suffix(".manifest.json")

    for required in (image_path, caption_path):
        if not required.exists() or not meta_path(required).exists():
            return f"missing {required.name}"
    image_meta = read_json(meta_path(image_path))
    caption_meta = read_json(meta_path(caption_path))
    for label, meta in (("image", image_meta), ("caption", caption_meta)):
        if meta.get("records_fingerprint") != fingerprint:
            return f"{label} vectors were built for a different image set; re-run embed.py"
    if (not force and output.exists() and manifest_path.exists()
            and output.stat().st_mtime >= max(image_path.stat().st_mtime, caption_path.stat().st_mtime)):
        return "up to date"

    rows = load_caption_rows(layout.caption_file(captioner, variant))
    ordered = [rows[record.key] for record in records]
    image_vectors = np.load(image_path).astype(np.float32, copy=False)
    caption_vectors = np.load(caption_path).astype(np.float32, copy=False)
    if image_vectors.shape != caption_vectors.shape or image_vectors.shape[0] != len(records):
        return (f"shape mismatch: image {image_vectors.shape}, caption {caption_vectors.shape}, "
                f"records {len(records)}")

    caption_set_meta_path = layout.caption_meta(captioner, variant)
    caption_set_meta = read_json(caption_set_meta_path) if caption_set_meta_path.exists() else {}
    embedder_spec = config["embedders"][embedder]
    metadata = {
        # --- portable format v1 keys (read by the NDP notebook and exporters) ---
        "format_version": PORTABLE_INDEX_VERSION,
        "model_id": embedder_spec.get("model_id", embedder),
        "source": f"sweep:{name}",
        "query_task": embedder_spec.get("query_task"),
        "records": [
            {"dataset": record.dataset, "image_id": record.image_id,
             "caption": " ".join(str(row["caption"]).split()),
             "image_path": record.relative_path}
            for record, row in zip(records, ordered)
        ],
        # --- sweep provenance (extra keys; ignored by older readers) ---
        "sweep": config.get("name"),
        "config_name": name,
        "captioner": captioner,
        "caption_variant": variant,
        "caption_set": caption_set_name(captioner, variant),
        "embedder": embedder,
        "embedder_spec": embedder_spec,
        "vector_dimension": int(image_vectors.shape[1]),
        "records_fingerprint": fingerprint,
        "caption_generation": {key: caption_set_meta.get(key) for key in (
            "model", "hf_id", "prompt", "max_tokens", "kind", "target_words",
            "max_image_edge_pixels", "temperature", "seed", "extra_body", "server")},
        "caption_stats": caption_stats(ordered),
        "embedder_text_tokens": caption_meta.get("embedder_text_tokens"),
        "image_vector_meta": {key: image_meta.get(key) for key in ("embedder", "versions", "written_at")},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_name(f".{output.stem}.tmp.npz")
    np.savez(
        temp,
        metadata=np.frombuffer(json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))
                               .encode("utf-8"), dtype=np.uint8),
        image_vectors=image_vectors,
        caption_vectors=caption_vectors,
    )
    temp.replace(output)

    counts = Counter(record.dataset for record in records)
    write_json_atomic(manifest_path, {
        "file_name": output.name,
        "format_version": PORTABLE_INDEX_VERSION,
        "config_name": name,
        "model_id": metadata["model_id"],
        "record_count": len(records),
        "vector_dimension": metadata["vector_dimension"],
        "dataset_counts": dict(sorted(counts.items())),
        "caption_stats": metadata["caption_stats"],
        "embedder_text_tokens": metadata["embedder_text_tokens"],
        "size_bytes": output.stat().st_size,
        "sha256": sha256_file(output),
        "written_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    })
    return f"wrote {output.name} ({len(records)} x {metadata['vector_dimension']})"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--captioners", nargs="+")
    parser.add_argument("--variants", nargs="+")
    parser.add_argument("--embedders", nargs="+")
    parser.add_argument("--dataset-dir", type=Path)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    config = load_config(args.config)
    layout = Layout(args.root)
    records = load_records(args.dataset_dir or default_dataset_dir(), default_image_dir(),
                           config["datasets"], check_files=False)
    fingerprint = records_fingerprint(records)

    not_ready = 0
    for captioner in pick(config["captioners"], args.captioners, "captioner"):
        for variant in pick(config["caption_variants"], args.variants, "caption variant"):
            for embedder in pick(config["embedders"], args.embedders, "embedder"):
                status = pack_one(config, layout, records, fingerprint,
                                  captioner, variant, embedder, args.force)
                if status.startswith(("missing", "shape", "image", "caption")):
                    not_ready += 1
                print(f"{config_name(captioner, variant, embedder)}: {status}", flush=True)
    return 1 if not_ready else 0


if __name__ == "__main__":
    raise SystemExit(main())
