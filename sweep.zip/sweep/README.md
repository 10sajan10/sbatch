# sweep: captioner × caption length × embedder → vector databases + scores

A self-contained folder. Unzip it anywhere, point it at a GPU, and it produces
one vector database file (a portable NPZ) per combination of

| axis | default values (edit [`sweep.json`](sweep.json)) |
|---|---|
| captioner | `gemma3-4b` (google/gemma-3-4b-it), `gemma4-e2b` (google/gemma-4-E2B-it), `smolvlm2-500m` (HuggingFaceTB/SmolVLM2-500M-Video-Instruct), `qwen3vl-2b` (Qwen/Qwen3-VL-2B-Instruct); `gemma4-e4b` available, off |
| caption length | `kw` (15 keywords, 64-token cap), `tiny` / `short` / `long` (≈25 / 50 / 150 words; caps 32 / 64 / 191 tokens); `xlong` (250 words) available, off |
| embedder | `dfn5b` (ViT-H/14-378, 1024-d, 77-token text), `mobileclip2-s2` and `mobileclip2-s0` (512-d, 77), `siglip2-b16-256` (768-d, **64**); `jina-clip-v2`, `pe-core-s16-384`, `dfn5b-openclip` (reference) available, off |

over the five pinned benchmark datasets (CloudBench, CommonObjectsBench,
FireBench, INQUIRE-small, SageBench; 32,177 images), and scores every file on the
benchmark queries. Defaults: 4 × 4 × 4 = **64 NPZs**, each scored under 4 fusions.

Nothing outside this folder is needed: the data download, caption clean-up and
metric code are included (`data/`, `textproc.py`, `metrics.py`, the last two
copied verbatim from the earlier evaluator so scores stay comparable).

## Outputs

Everything goes under one root, `$SWEEP_ROOT` (default `sweep/runs/`):

```text
$SWEEP_ROOT/
  npz/<captioner>__<length>__<embedder>.npz     the 64 databases (+ .manifest.json with SHA-256)
  results/sweep_summary.csv                     scores: one row per config × fusion × dataset + overall
  results/<config>/<fusion>/                    per-query metrics
  captions/<captioner>__<length>.jsonl          every caption with completion_tokens, finish_reason
  vectors/<embedder>/                           intermediate image and caption vectors
  logs/                                         Slurm and vLLM logs
```

Each NPZ holds `metadata` (UTF-8 JSON: records with dataset, image_id, caption,
image_path, plus the caption prompt, token cap, model, caption statistics, share
of captions longer than the embedder's text window, package versions),
`image_vectors` and `caption_vectors` (float32, L2-normalised). Score composite
= 0.5·MRR + 0.5·Success@25, isolated per dataset, equal-weight over datasets.

## Run it on a Slurm cluster (CHPC)

1. **Configure** the marked lines in [`jobs/env.sh`](jobs/env.sh): `SWEEP_ACCOUNT`,
   `SWEEP_PARTITION`, `SWEEP_QOS` (needed on Granite) and `SWEEP_GRES`
   (from `mychpc batch`), and `SWEEP_ROOT` (default `/scratch/general/vast/$USER/imsearch-sweep`).
2. **Set up once on a login node** (needs internet; about an hour, mostly downloads).
   Accept the Gemma terms on Hugging Face first, then:
   ```bash
   source sweep/jobs/env.sh
   sweep/jobs/setup_env.sh venv                 # Python >= 3.10 venv from requirements.txt
   $SWEEP_ROOT/venv/bin/hf auth login           # Read token, for the gated Gemma weights
   sweep/jobs/setup_env.sh container data models check
   ```
3. **Optional CPU dry run** (a minute; fake captioner and embedder, real code paths):
   `PYTHON=$SWEEP_ROOT/venv/bin/python sweep/tests/dry_run.sh`
4. **GPU smoke test**, 20 images per captioner and length:
   ```bash
   sweep/jobs/submit_sweep.sh --smoke 20
   head -n 3 $SWEEP_ROOT/captions/*__long.jsonl     # captions look right? no markdown, no "thinking"?
   ```
5. **Submit everything**: `sweep/jobs/submit_sweep.sh` (add `--dry-run` to print the
   `sbatch` commands first). One caption job per captioner and one image job per
   embedder run in parallel; a finalize job per embedder then embeds captions,
   writes the NPZs and scores them. Every stage skips finished work, so
   resubmitting after a failure only redoes what is missing.

## Run it on one machine with Ollama (no Slurm)

[`sweep_ollama.json`](sweep_ollama.json) is the edge matrix with the captioners
served by Ollama (`gemma3:4b`, `gemma4:e2b`, `qwen3-vl:2b`), caption lengths keywords /
50 / 75 / 100 words (token caps 64 / 64 / 96 / 128), and embedders MobileCLIP2-S0,
SigLIP2-B/16, DFN5B and jina-clip-v2 (8192-token text, the only one that reads 100-word
captions in full): 3 × 4 × 4 = **48 NPZs**. Use the **same
tags as the edge device** (`ollama list` there), so quality matches the edge's
cost measurements. [`jobs/run_local.sh`](jobs/run_local.sh) runs every stage in
order on one GPU machine:

```bash
export SWEEP_ROOT=~/imsearch-runs SWEEP_CONFIG=$PWD/sweep/sweep_ollama.json
sweep/jobs/setup_env.sh venv data models check    # Python env, datasets, embedders (no HF login needed)
ollama pull gemma3:4b; ollama pull gemma4:e2b; ollama pull qwen3-vl:2b
OLLAMA_NUM_PARALLEL=4 ollama serve &               # if Ollama is not already running
sweep/jobs/run_local.sh --max-images 20            # quick test, then check the captions
sweep/jobs/run_local.sh                            # everything: NPZs + scores
```

It runs inside `tmux` happily and resumes if stopped. Any other OpenAI-compatible
server works too: `ENDPOINT=http://127.0.0.1:8000/v1 sweep/jobs/run_local.sh`.

## Load an NPZ into a vector database

```bash
python3 sweep/load_index.py --npz runs/npz/gemma3-4b__short__dfn5b.npz \
    --backend milvus --path runs/db/milvus-short.db --recreate --probe 200   # Milvus Lite
python3 sweep/load_index.py --npz ... --backend qdrant   --url http://127.0.0.1:6333 --recreate
python3 sweep/load_index.py --npz ... --backend weaviate --url http://127.0.0.1:8080 --recreate
```

The report records load time, points/s, disk size, p50/p95 query latency and
recall@k against exact search. qdrant-client's embedded `--path` mode is brute
force (fine for checking data, not for timing). Weaviate was not tested end to
end; try `--probe 5` first.

## Things to keep straight

- **Caption length is set in tokens.** All caption lengths share one over-asking
  prompt; only the hard token cap differs (caps from Gemma's 1.16 tokens/word).
  Every caption row records `completion_tokens`, so plot quality against tokens.
- **Text windows differ.** DFN5B and MobileCLIP2 read 77 tokens, SigLIP2 64. Text
  past the window reaches only BM25. `fraction_captions_over_text_limit` shows how often.
- **Image vectors are computed once per embedder** and shared by all caption sets,
  so `image_only` scores must be identical across captioners (a free sanity check).
- **A few images may have no caption.** Failures are retried once at low load; any
  still failing are listed in `<set>.errors.jsonl`. A set is packed if at least
  99.5% of images have a caption (`captioning.min_coverage`); the rest get an empty
  caption, counted in each NPZ as `captions_missing`. Report it if it is not zero.
- **Same model, same precision on every machine.** Cluster quality transfers to an
  edge device only with identical weights, runtime and precision (vLLM, BF16 here).
- **Gemma 4 thinking stays off**; check smoke-test captions contain no reasoning text.
- **Licenses.** DFN5B is CC-BY-NC-4.0, MobileCLIP2 uses Apple's model license,
  Gemma has its own terms. Fine for research; note them in the paper.

## Files

| file | role |
|---|---|
| [`sweep.json`](sweep.json) | the matrix: datasets, captioners, lengths, embedders, fusions |
| [`common.py`](common.py) | config, canonical image order, output layout |
| [`caption.py`](caption.py) | stage 1: captions via any OpenAI-compatible server |
| [`embedders.py`](embedders.py) | DFN5B (transformers), MobileCLIP2 / SigLIP2 (open_clip), jina-clip-v2, fake |
| [`embed.py`](embed.py) | stage 2: image and caption vectors |
| [`pack.py`](pack.py) | stage 3: NPZ + manifest |
| [`evaluate_npz.py`](evaluate_npz.py) | stage 4: benchmark scores |
| [`load_index.py`](load_index.py) | optional: load + probe Qdrant / Milvus Lite / Weaviate |
| [`metrics.py`](metrics.py), [`textproc.py`](textproc.py) | metric and caption clean-up code from the original evaluator |
| [`data/`](data/download_datasets.sh) | download the pinned datasets, extract images |
| [`jobs/`](jobs/env.sh) | Slurm settings, setup, submit, job scripts |
| [`tests/`](tests/dry_run.sh) | synthetic fixture, fake VLM server, dry run, embedder smoke test |
