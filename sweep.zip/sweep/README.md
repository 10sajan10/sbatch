# sweep — captioner × caption length × embedder, built once, loaded anywhere

Builds one vector database file (a portable NPZ) for every combination of

| axis | default values (edit [`sweep.json`](sweep.json)) |
|---|---|
| captioner | `gemma3-4b` (google/gemma-3-4b-it), `gemma4-e2b` (google/gemma-4-E2B-it), `smolvlm2-500m` (HuggingFaceTB/SmolVLM2-500M-Video-Instruct), `qwen3vl-2b` (Qwen/Qwen3-VL-2B-Instruct); `gemma4-e4b` available, off |
| caption variant | `kw` (15 keywords, 64-token cap), `tiny` / `short` / `long` (≈25 / 50 / 150 words; caps 32 / 64 / 191 tokens); `xlong` (250 words, edge_v3) available, off |
| embedder | `dfn5b` (ViT-H/14-378, 1024-d, 77-token text), `mobileclip2-s2` and `mobileclip2-s0` (512-d, 77), `siglip2-b16-256` (768-d, **64**); `jina-clip-v2` (8192), `pe-core-s16-384` (**32**), `dfn5b-openclip` (reference) available, off |

over the five pinned benchmark datasets, scores every file on the benchmark
queries, and loads any of them into Qdrant, Milvus (Lite), or Weaviate on the
edge node. Defaults give 4 × 4 × 4 = **64 NPZs**, each scored under 4 fusions.

Everything lives in this folder and writes under one output root
(`$SWEEP_ROOT`, default `sweep/runs/`, gitignored). Nothing here touches
`edge_v1`/`edge_v2`/`edge_v3` state.

## Why it is built this way

- **Caption length is the experiment's main knob.** All caption variants share
  one over-asking prompt and differ only in the hard token cap, exactly as
  edge_v3 controls length (see [`../edge_v3/README.md`](../edge_v3/README.md)).
  Every caption row stores `completion_tokens` and `finish_reason`, because VLM
  energy on Jetson-class hardware is dominated by generated tokens. The keyword
  variant uses its own prompt.
- **Image vectors are computed once per embedder.** They don't depend on the
  captioner, so ~32k images are embedded once per embedder (4 times), not 64 times.
- **Quality never depends on the database.** Scoring uses exact cosine plus
  BM25 over the stored captions, with the metric and fusion code imported from
  [`../scripts/benchmark_search.py`](../scripts/benchmark_search.py).
  [`tests/check_fusion_parity.py`](tests/check_fusion_parity.py) proves the
  rankings are identical to `dual_vector_search`, so sweep numbers line up with
  the existing edge_v2/edge_v3 results.
- **Databases are loaded, not converted.** Qdrant segments, a Milvus Lite data
  directory, and Weaviate shards are engine-specific (and the cluster is x86,
  the Thor is ARM). The NPZ is the source of truth;
  [`load_index.py`](load_index.py) bulk-loads it into any engine and measures
  load time, disk size, query latency, and HNSW recall against exact search.

## Pipeline

```text
benchmark Parquet + extracted JPEGs
        │
caption.py ─── one JSONL per (captioner, variant)        runs/captions/
        │       vLLM / Ollama, OpenAI-compatible, resumable
embed.py  ──── image vectors once per embedder           runs/vectors/<embedder>/images.npy
        │       caption vectors per (embedder, set)      runs/vectors/<embedder>/captions__*.npy
pack.py   ──── one portable NPZ per combination          runs/npz/<captioner>__<variant>__<embedder>.npz
        │
evaluate_npz.py  quality per NPZ × fusion                runs/results/sweep_summary.csv
load_index.py    NPZ → Qdrant | Milvus Lite | Weaviate   runs/db/<backend>__<config>.json
```

The NPZ keeps the repo's portable format (`format_version` 1, as written by
`scripts/export_edge_v3_npz.py`), with extra provenance keys: caption prompt,
token cap, server and model, caption statistics, the share of captions longer
than the embedder's text window, and package versions.

## Run it on CHPC

1. **Configure** — edit the marked lines in [`jobs/env.sh`](jobs/env.sh):
   `SWEEP_ACCOUNT` and `SWEEP_PARTITION` (from `myallocation`) and `SWEEP_ROOT`
   (default `/scratch/general/vast/$USER/imsearch-sweep`).
2. **Set up once on a login node** (needs internet; ~1 h, mostly downloads).
   Accept the Gemma terms on Hugging Face first, then:
   ```bash
   sweep/jobs/setup_env.sh venv          # Python >= 3.10 venv from requirements.txt
   $SWEEP_ROOT/venv/bin/hf auth login    # for the gated Gemma weights
   sweep/jobs/setup_env.sh               # container, models, datasets, check
   ```
3. **Dry run on the login node** (CPU, about a minute; fake captioner, fake
   embedder, synthetic data, real code paths):
   ```bash
   PYTHON=$SWEEP_ROOT/venv/bin/python sweep/tests/dry_run.sh
   ```
4. **Smoke test on a GPU**, 20 images per variant, before the full run:
   ```bash
   SWEEP_DIR=$PWD/sweep sbatch -A <account> -p <partition> --gres=gpu:1 --time=01:00:00 \
       sweep/jobs/caption.slurm gemma4-e2b --max-images 20
   ```
   Read a few rows of `runs/captions/gemma4-e2b__long.jsonl` and check that
   `finish_reason` is `length` for the caption variants and the text looks
   right. Keep the files: the full run reuses those 20 captions and resumes.
5. **Submit everything**:
   ```bash
   sweep/jobs/submit_sweep.sh --dry-run   # show the sbatch commands
   sweep/jobs/submit_sweep.sh
   ```
   One caption job per captioner and one image-embedding job per embedder
   run in parallel. A finalize job per embedder then embeds captions, packs,
   and scores. Every stage skips finished work, so resubmitting after a failure
   only redoes what's missing.

Results: `runs/results/sweep_summary.csv`. It has one row per config ×
fusion × dataset plus an `overall` row (equal-weight mean, `composite` =
0.5·MRR + 0.5·Success@25, as in the repo), with the caption's mean
completion tokens alongside for plotting quality against generation cost.

## Move a database between engines

Copy the NPZ (and its `.manifest.json`, which has the SHA-256) to the node,
then load it into whichever engine you're measuring:

```bash
# Milvus Lite: embedded, data directory ends in .db
python3 sweep/load_index.py --npz runs/npz/gemma3-4b__short__dfn5b.npz \
    --backend milvus --path runs/db/milvus-short.db --recreate --probe 200

# Qdrant server (the edge_v3 container, scripts in edge_v3/scripts/run_qdrant.sh)
python3 sweep/load_index.py --npz ... --backend qdrant --url http://127.0.0.1:6333 --recreate

# Weaviate server (scripts/run_weaviate.sh)
python3 sweep/load_index.py --npz ... --backend weaviate --url http://127.0.0.1:8080 --recreate
```

Each backend gets the edge_v3 shape: named `image` and `caption` cosine
vectors, HNSW (`--hnsw-m`, `--hnsw-ef-construction`, `--ef-search`), payload
`dataset`, `image_id`, `caption`, `image_path`, and the edge_v3 point IDs.
The JSON report records load time, points/s, disk bytes (embedded modes),
p50/p95 query latency, and recall@k of the database's top-k against exact
search.

On the Thor, run any stage in the container: build
[`docker/Dockerfile.thor`](docker/Dockerfile.thor) once, then use
[`jobs/thor_run.sh`](jobs/thor_run.sh).

## Things to keep straight in the paper

- **Same model, same precision on both machines.** Quality from the cluster
  transfers to the Thor only if the captioner is identical: same weights, same
  runtime, same precision. The cluster runs vLLM on the HF weights in BF16. If
  the Thor serves Gemma 4 through Ollama (a quantized GGUF), the captions
  differ, so serve it with vLLM on the Thor too or caption with Ollama
  everywhere. Run the 200-image equivalence check either way.
- **Gemma 4 thinking stays off.** vLLM only enables it per request; nothing
  here enables it. Ollama's OpenAI endpoint may differ: check that captions
  aren't empty and contain no reasoning text before trusting a run.
- **qdrant-client's embedded mode (`--path`) is brute force in Python.** It
  ignores HNSW and is fine for checking data but not for latency. Use a Qdrant
  server for timing. The report notes this.
- **The Weaviate backend was not run end-to-end here** (no server available).
  It uses the same REST shapes as `scripts/image_search_pipeline.py`, but do one
  small `--probe 5` load before relying on it.
- **Licenses.** DFN5B is CC-BY-NC-4.0 and MobileCLIP2 uses Apple's
  model license. Gemma has its own terms. Fine for research; note them in the
  paper.
- **Caption length is set in tokens, not words.** The token caps come from
  Gemma's measured 1.16 tokens/word. Qwen and SmolVLM tokenize differently, so
  the same cap yields slightly different word counts. Every caption row records
  `completion_tokens`, so plot quality against tokens.
- **Text windows differ.** DFN5B and MobileCLIP2 read 77 tokens, SigLIP2 64.
  Caption text beyond the window never reaches the caption vector, only BM25.
  `fraction_captions_over_text_limit` in the summary shows how often that happens.
- **Check `edge_v2_image_only` before citing it.** That historical DFN5B
  image-only run scores near random (composite 0.055), while edge_v1's hybrid
  shows the DFN5B image leg is informative. It is almost certainly an
  evaluation bug in that run. The sweep's `image_only` fusion re-measures it,
  and `dfn5b-openclip` gives a reference implementation for comparison.
- **Fusions.** `image_only` is the no-captioning baseline and is identical
  across captioners for a given embedder (a free sanity check).
  `caption_only` and `bm25_only` are diagnostics.

## Files

| file | role |
|---|---|
| [`sweep.json`](sweep.json) | the matrix: datasets, captioners, variants, embedders, fusions |
| [`common.py`](common.py) | config, canonical image order and fingerprint, output layout |
| [`caption.py`](caption.py) | stage 1, OpenAI-compatible captioning client |
| [`embedders.py`](embedders.py) | DFN5B (transformers), MobileCLIP2 (open_clip), jina-clip-v2, fake |
| [`embed.py`](embed.py) | stage 2, image and caption vectors |
| [`pack.py`](pack.py) | stage 3, portable NPZ + manifest |
| [`evaluate_npz.py`](evaluate_npz.py) | stage 4, benchmark scoring |
| [`load_index.py`](load_index.py) | stage 5, load + probe Qdrant / Milvus / Weaviate |
| [`jobs/`](jobs/env.sh) | Slurm jobs, setup, submit, Thor launcher |
| [`tests/`](tests/dry_run.sh) | fixture, fake server, dry run, fusion parity check |
