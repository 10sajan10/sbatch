"""Retrieval metrics, copied verbatim from the original evaluator
(scripts/benchmark_search.py in image-search-at-edge) so the sweep runs on its own
and its numbers stay comparable with the earlier edge_v1/v2/v3 results.

Only the benchmark id, query and relevance columns are read; annotation
columns (summaries, tags, ...) are never touched.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq


DATASET_EVAL_COLUMNS = {
    "cloudbench": {"image_id": "image_id", "query_id": "query_id", "query_text": "query_text", "relevance": "relevance_label"},
    "commonobjectsbench": {"image_id": "image_id", "query_id": "query_id", "query_text": "query_text", "relevance": "relevance_label"},
    "firebench": {"image_id": "image_id", "query_id": "query_id", "query_text": "query_text", "relevance": "relevance_label"},
    "sagebench": {"image_id": "image_id", "query_id": "query_id", "query_text": "query_text", "relevance": "relevance_label"},
    "inquire-small": {"image_id": "inat24_image_id", "query_id": "query_id", "query_text": "query", "relevance": "relevant"},
}


class QueryGroundTruth:
    __slots__ = ("query_id", "query_text", "relevant", "corpus_seen")

    def __init__(self, query_id: str, query_text: str):
        self.query_id = query_id
        self.query_text = query_text
        self.relevant: set[str] = set()
        self.corpus_seen: set[str] = set()


def load_ground_truth(dataset_dir: Path, dataset: str) -> tuple[dict[str, QueryGroundTruth], set[str]]:
    columns = DATASET_EVAL_COLUMNS[dataset]
    data_dir = dataset_dir / dataset / "data"
    parquet_paths = sorted(data_dir.glob("*.parquet"))
    if not parquet_paths:
        raise FileNotFoundError(f"No Parquet shards found under {data_dir}")

    queries: dict[str, QueryGroundTruth] = {}
    corpus: set[str] = set()
    wanted = [columns["query_id"], columns["query_text"], columns["image_id"], columns["relevance"]]
    for parquet_path in parquet_paths:
        table = pq.read_table(parquet_path, columns=wanted)
        query_ids = table.column(columns["query_id"]).to_pylist()
        query_texts = table.column(columns["query_text"]).to_pylist()
        image_ids = table.column(columns["image_id"]).to_pylist()
        relevances = table.column(columns["relevance"]).to_pylist()
        for query_id, query_text, image_id, relevance in zip(query_ids, query_texts, image_ids, relevances):
            query_id = str(query_id)
            image_id = str(image_id)
            corpus.add(image_id)
            group = queries.get(query_id)
            if group is None:
                group = QueryGroundTruth(query_id, str(query_text))
                queries[query_id] = group
            if int(relevance):
                group.relevant.add(image_id)
    return queries, corpus


_BM25_TOKEN = re.compile(r"\w+", re.UNICODE)


class LocalBM25:
    """BM25 over Qdrant caption payloads using Weaviate's default k1/b.

    Qdrant's collection predates its sparse-vector search setup, so the lexical
    leg is evaluated over the exact stored captions rather than silently
    dropping BM25 from the published three-way fusion.
    """

    def __init__(self, captions: list[str], *, k1: float = 1.2, b: float = 0.75):
        self.term_frequencies = [Counter(self.tokenize(text)) for text in captions]
        self.lengths = np.asarray(
            [sum(counts.values()) for counts in self.term_frequencies], dtype=np.float32
        )
        self.average_length = float(self.lengths.mean()) if len(self.lengths) else 0.0
        self.k1 = k1
        self.b = b
        self.document_frequencies: Counter[str] = Counter()
        for counts in self.term_frequencies:
            self.document_frequencies.update(counts.keys())

    @staticmethod
    def tokenize(text: str) -> list[str]:
        return _BM25_TOKEN.findall(text.lower())

    def scores(self, query: str) -> np.ndarray:
        scores = np.zeros(len(self.term_frequencies), dtype=np.float32)
        if not len(scores) or self.average_length <= 0:
            return scores
        document_count = len(self.term_frequencies)
        length_norm = self.k1 * (
            1.0 - self.b + self.b * self.lengths / self.average_length
        )
        for term in set(self.tokenize(query)):
            document_frequency = self.document_frequencies.get(term, 0)
            if not document_frequency:
                continue
            inverse_document_frequency = math.log(
                1.0 + (document_count - document_frequency + 0.5)
                / (document_frequency + 0.5)
            )
            frequencies = np.fromiter(
                (counts.get(term, 0) for counts in self.term_frequencies),
                dtype=np.float32,
                count=document_count,
            )
            scores += inverse_document_frequency * (
                frequencies * (self.k1 + 1.0) / (frequencies + length_norm)
            )
        return scores


def relative_score(values: np.ndarray) -> np.ndarray:
    low = float(values.min())
    high = float(values.max())
    if high - low < 1e-12:
        return np.zeros_like(values)
    return (values - low) / (high - low)


def diversity_at_k(vectors: list[list[float]]) -> float:
    """Diversity = 1 - ILS (Intra-List Similarity), matching imsearch_eval's
    actual formula (imsearch_eval/framework/evaluator.py:compute_ils):
    ILS = mean pairwise cosine similarity across all returned vectors.

    Stored vectors are already L2-normalized (see embed_images/embed_text in
    image_search_pipeline.py), so cosine similarity reduces to a plain dot
    product -- no extra normalization or sklearn dependency needed.
    """
    if len(vectors) < 2:
        return 0.0
    matrix = np.asarray(vectors, dtype=np.float64)
    sim = matrix @ matrix.T
    n = sim.shape[0]
    i, j = np.triu_indices(n, k=1)
    ils = float(np.mean(sim[i, j]))
    return 1.0 - ils


def evaluate_query(
    ranked: list[tuple[str, str, list[float]]], relevant_keys: set[tuple[str, str]], k: int
) -> dict[str, float]:
    window = ranked[:k]
    flags = [1 if (ds, img) in relevant_keys else 0 for ds, img, _vec in window]
    k_effective = len(flags)
    num_retrieved_relevant = sum(flags)
    first_hit = next((i + 1 for i, flag in enumerate(flags) if flag), None)
    reciprocal_rank = 1.0 / first_hit if first_hit else 0.0
    hit = 1 if num_retrieved_relevant > 0 else 0
    precision = num_retrieved_relevant / k_effective if k_effective else 0.0
    total_relevant = len(relevant_keys)
    recall = num_retrieved_relevant / total_relevant if total_relevant else 0.0
    dcg = sum(flag / math.log2(i + 2) for i, flag in enumerate(flags))
    ideal_hits = min(total_relevant, k_effective)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_hits))
    ndcg = dcg / idcg if idcg > 0 else 0.0
    diversity = diversity_at_k([vec for _ds, _img, vec in window])
    return {
        "reciprocal_rank": reciprocal_rank,
        "hit": float(hit),
        "precision_at_k": precision,
        "recall_at_k": recall,
        "ndcg_at_k": ndcg,
        "diversity_at_k": diversity,
        "k_effective": float(k_effective),
        "num_relevant_total": float(total_relevant),
        "num_relevant_retrieved": float(num_retrieved_relevant),
    }
