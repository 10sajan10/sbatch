#!/usr/bin/env bash
# One-time setup on a cluster login node (needs internet). Idempotent: re-run
# any time; finished steps are skipped.
#
#   sweep/jobs/setup_env.sh            # everything
#   sweep/jobs/setup_env.sh venv data  # only some steps: venv, container, models, data, check
#
# Gemma weights are gated: accept the terms on each model page on Hugging Face,
# then run `$VENV_DIR/bin/hf auth login` once before the "models" step.
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/env.sh"

STEPS=("$@")
[[ ${#STEPS[@]} -eq 0 ]] && STEPS=(venv container models data check)
want() { [[ " ${STEPS[*]} " == *" $1 "* ]]; }
mkdir -p "$SWEEP_ROOT"/{logs,containers} "$MODELS_DIR" "$HF_HOME" "$APPTAINER_CACHEDIR" "$APPTAINER_TMPDIR"

if want venv; then
  echo "== venv: $VENV_DIR"
  BASE_PYTHON="${BASE_PYTHON:-python3}"
  if ! "$BASE_PYTHON" -c 'import sys; sys.exit(sys.version_info < (3, 10))' 2>/dev/null; then
    echo "Need Python >= 3.10 for the venv; load one first (e.g. 'module load python' or a" >&2
    echo "miniforge module) or set BASE_PYTHON=/path/to/python3.11, then re-run." >&2
    exit 1
  fi
  [[ -x "$PYTHON" ]] || "$BASE_PYTHON" -m venv "$VENV_DIR"
  "$PYTHON" -m pip install --upgrade pip
  "$PYTHON" -m pip install -r "$SWEEP_DIR/requirements.txt"
fi

if want container; then
  echo "== vLLM container: $VLLM_SIF"
  load_apptainer
  [[ -f "$VLLM_SIF" ]] || apptainer pull "$VLLM_SIF" "$VLLM_IMAGE"
fi

if want models; then
  echo "== models: $MODELS_DIR"
  HF="${VENV_DIR}/bin/hf"
  # Captioners served by Ollama are pulled with `ollama pull`, not from Hugging Face.
  mapfile -t HF_CAPTIONERS < <("$PYTHON" -c '
import json, os
config = json.load(open(os.environ["SWEEP_CONFIG"]))
for name, spec in config["captioners"].items():
    if spec.get("enabled", True) and spec.get("runtime", "vllm") != "ollama":
        print(name)
')
  if [[ ${#HF_CAPTIONERS[@]} -gt 0 ]] && ! "$HF" auth whoami >/dev/null 2>&1; then
    cat >&2 <<MSG
Not logged in to Hugging Face (needed for the gated Gemma weights). Run this yourself,
paste a Read token from huggingface.co/settings/tokens, then re-run this step:
  source sweep/jobs/env.sh && $HF auth login
The token is stored under \$HF_HOME ($HF_HOME); never put it in the repo.
MSG
    exit 1
  fi
  for captioner in "${HF_CAPTIONERS[@]}"; do
    eval "$("$PYTHON" "$SWEEP_DIR/common.py" shell-captioner --captioner "$captioner")"
    hf_id="$("$PYTHON" -c "import json,sys; print(json.load(open(sys.argv[1]))['captioners'][sys.argv[2]]['hf_id'])" "$SWEEP_CONFIG" "$captioner")"
    [[ -f "$MODELS_DIR/$MODEL_DIR/config.json" ]] || "$HF" download "$hf_id" --local-dir "$MODELS_DIR/$MODEL_DIR"
  done
  # Embedders with a model_dir are downloaded by model_id; open_clip ones are
  # fetched into $HF_HOME by building them once on the CPU.
  "$PYTHON" - <<'EOF'
import json, os, subprocess, sys
from pathlib import Path
config = json.load(open(os.environ["SWEEP_CONFIG"]))
models = Path(os.environ["MODELS_DIR"])
for name, spec in config["embedders"].items():
    if not spec.get("enabled", True) or spec["kind"] == "fake":
        continue
    if spec.get("model_dir"):
        target = models / spec["model_dir"]
        if not (target / "config.json").exists():
            subprocess.run([os.path.join(os.environ["VENV_DIR"], "bin", "hf"), "download",
                            spec["model_id"], "--local-dir", str(target)], check=True)
        if spec["kind"] == "jina_clip":
            # Its trust_remote_code modules live in other HF repos; load once while
            # online so they are cached in $HF_HOME for the offline embedding jobs.
            from transformers import AutoModel
            AutoModel.from_pretrained(str(target), trust_remote_code=True,
                                      use_text_flash_attn=False, use_vision_xformers=False)
            print(f"cached {name} remote code in {os.environ['HF_HOME']}")
    elif spec["kind"] == "open_clip":
        import open_clip
        open_clip.create_model_and_transforms(spec["model_name"], pretrained=spec["pretrained"])
        open_clip.get_tokenizer(spec["model_name"])  # SigLIP2 fetches an HF tokenizer separately
        print(f"cached {name} ({spec['model_name']}:{spec['pretrained']}) in {os.environ['HF_HOME']}")
EOF
fi

if want data; then
  echo "== benchmark datasets: $DATASET_DIR -> $IMAGE_DIR"
  HF_BIN="${VENV_DIR}/bin/hf" BENCHMARK_DATA_DIR="$DATASET_DIR" "$SWEEP_DIR/data/download_datasets.sh"
  "$PYTHON" "$SWEEP_DIR/data/extract_images.py" --dataset-root "$DATASET_DIR" --output-root "$IMAGE_DIR"
fi

if want check; then
  echo "== check"
  "$PYTHON" - <<'EOF'
import os, sys
sys.path.insert(0, os.environ["SWEEP_HOME"])
from sweep.common import default_dataset_dir, default_image_dir, load_config, load_records
config = load_config()
records = load_records(default_dataset_dir(), default_image_dir(), config["datasets"])
print(f"{len(records)} benchmark images ready across {len(config['datasets'])} datasets")
EOF
  echo "Next: sweep/tests/dry_run.sh (CPU), then sweep/jobs/submit_sweep.sh --smoke 20 (GPU test), then submit_sweep.sh"
fi
