# Site settings for the sweep jobs. Sourced by every script in sweep/jobs/.
# Edit the four marked values once for your allocation; everything else derives
# from SWEEP_ROOT. Any variable already set in your shell wins.

# --- EDIT: Slurm allocation. On a CHPC login node, `myallocation` lists the
# account/partition pairs you can use (e.g. a notchpeak-gpu or granite-gpu pair).
export SWEEP_ACCOUNT="${SWEEP_ACCOUNT:-}"
export SWEEP_PARTITION="${SWEEP_PARTITION:-}"
export SWEEP_QOS="${SWEEP_QOS:-}"                 # leave empty unless your partition needs one
export SWEEP_GRES="${SWEEP_GRES:-gpu:1}"          # e.g. gpu:a100:1 to pin a GPU type

# --- EDIT: a large, fast filesystem (models ~30 GB, vLLM image ~15 GB, outputs ~5 GB).
export SWEEP_ROOT="${SWEEP_ROOT:-/scratch/general/vast/${USER}/imsearch-sweep}"

# --- Derived locations (change only if you keep things elsewhere)
SWEEP_DIR="${SWEEP_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)}"
export SWEEP_DIR
export REPO_DIR="${REPO_DIR:-$(cd -- "${SWEEP_DIR}/.." && pwd)}"
export SWEEP_CONFIG="${SWEEP_CONFIG:-${SWEEP_DIR}/sweep.json}"
export MODELS_DIR="${MODELS_DIR:-${SWEEP_ROOT}/models}"
export DATASET_DIR="${DATASET_DIR:-${SWEEP_ROOT}/benchmarking/datasets}"
export IMAGE_DIR="${IMAGE_DIR:-${SWEEP_ROOT}/benchmarking/image}"
export VENV_DIR="${VENV_DIR:-${SWEEP_ROOT}/venv}"
export HF_HOME="${HF_HOME:-${SWEEP_ROOT}/hf-cache}"
export APPTAINER_CACHEDIR="${APPTAINER_CACHEDIR:-${SWEEP_ROOT}/apptainer-cache}"
export APPTAINER_TMPDIR="${APPTAINER_TMPDIR:-${SWEEP_ROOT}/apptainer-tmp}"

# vLLM v0.19.0 is the first release with Gemma 4 support (and still serves
# Gemma 3). Pin it; record any change in the paper's config table.
export VLLM_IMAGE="${VLLM_IMAGE:-docker://vllm/vllm-openai:v0.19.0}"
export VLLM_SIF="${VLLM_SIF:-${SWEEP_ROOT}/containers/vllm-openai_v0.19.0.sif}"
export VLLM_GPU_MEMORY_UTILIZATION="${VLLM_GPU_MEMORY_UTILIZATION:-0.85}"
export CAPTION_CONCURRENCY="${CAPTION_CONCURRENCY:-32}"

PYTHON="${VENV_DIR}/bin/python"
export PYTHON

load_apptainer() {
  if ! command -v apptainer >/dev/null 2>&1; then
    module load apptainer 2>/dev/null || true
  fi
  command -v apptainer >/dev/null 2>&1 || {
    echo "apptainer not found (tried 'module load apptainer')" >&2
    return 1
  }
}

require_allocation() {
  if [[ -z "$SWEEP_ACCOUNT" || -z "$SWEEP_PARTITION" ]]; then
    echo "Set SWEEP_ACCOUNT and SWEEP_PARTITION in sweep/jobs/env.sh (see 'myallocation')." >&2
    return 1
  fi
}
