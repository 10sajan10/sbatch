# Site settings for the sweep jobs. Sourced by every script in sweep/jobs/.
# Edit the four marked values once for your allocation; everything else derives
# from SWEEP_ROOT. Any variable already set in your shell wins.

# --- EDIT: Slurm allocation. On a CHPC login node, `mychpc batch` lists the
# account / partition / QOS combinations you can use. SWEEP_ACCOUNT is the group
# allocation (e.g. your PI's), not your uNID; jobs still run as you.
#   Notchpeak general GPUs:  account notchpeak-gpu, partition notchpeak-gpu, QOS empty
#   Granite (incl. RAI):     a QOS is mandatory, e.g. account parashar + QOS rai-gpu-grn
export SWEEP_ACCOUNT="${SWEEP_ACCOUNT:-rai}"
export SWEEP_PARTITION="${SWEEP_PARTITION:-rai-gpu-grn}"
export SWEEP_QOS="${SWEEP_QOS:-rai-gpu-grn}"              # required on granite; empty elsewhere
export SWEEP_GRES="${SWEEP_GRES:-gpu:1}"          # pin a type: gpu:h100nvl:1, gpu:l40s:1, gpu:a100:1, gpu:3090:1

# Wall-clock limits per job type. Lower them if your QOS has a shorter MaxWall
# (sacctmgr -n show qos <qos> format=name,maxwall). Caption jobs resume where
# they stopped, so a short limit only means resubmitting.
export SWEEP_TIME_CAPTION="${SWEEP_TIME_CAPTION:-24:00:00}"
export SWEEP_TIME_IMAGES="${SWEEP_TIME_IMAGES:-06:00:00}"
export SWEEP_TIME_FINALIZE="${SWEEP_TIME_FINALIZE:-06:00:00}"

# --- EDIT: a large, fast filesystem (models ~30 GB, vLLM image ~15 GB, outputs ~5 GB).
export SWEEP_ROOT="${SWEEP_ROOT:-/scratch/general/vast/${USER}/imsearch-sweep}"

# --- Derived locations (change only if you keep things elsewhere)
SWEEP_DIR="${SWEEP_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)}"
export SWEEP_DIR
# Folder that contains sweep/ (Python imports it as a package from there).
export SWEEP_HOME="${SWEEP_HOME:-$(cd -- "${SWEEP_DIR}/.." && pwd)}"
export SWEEP_CONFIG="${SWEEP_CONFIG:-${SWEEP_DIR}/sweep.json}"
export MODELS_DIR="${MODELS_DIR:-${SWEEP_ROOT}/models}"
export DATASET_DIR="${DATASET_DIR:-${SWEEP_ROOT}/benchmarking/datasets}"
export IMAGE_DIR="${IMAGE_DIR:-${SWEEP_ROOT}/benchmarking/image}"
export VENV_DIR="${VENV_DIR:-${SWEEP_ROOT}/venv}"
export HF_HOME="${HF_HOME:-${SWEEP_ROOT}/hf-cache}"
export APPTAINER_CACHEDIR="${APPTAINER_CACHEDIR:-${SWEEP_ROOT}/apptainer-cache}"
export APPTAINER_TMPDIR="${APPTAINER_TMPDIR:-${SWEEP_ROOT}/apptainer-tmp}"

# vLLM v0.19.0 is the first release with Gemma 4 support (and still serves
# Gemma 3). Pin it; record any change in the paper's config table.
export VLLM_IMAGE="${VLLM_IMAGE:-docker://vllm/vllm-openai:v0.19.0}"
export VLLM_SIF="${VLLM_SIF:-${SWEEP_ROOT}/containers/vllm-openai_v0.19.0.sif}"
export VLLM_GPU_MEMORY_UTILIZATION="${VLLM_GPU_MEMORY_UTILIZATION:-0.85}"
export CAPTION_CONCURRENCY="${CAPTION_CONCURRENCY:-32}"

PYTHON="${VENV_DIR}/bin/python"
export PYTHON

load_apptainer() {
  if ! command -v apptainer >/dev/null 2>&1; then
    module load apptainer 2>/dev/null || true
  fi
  command -v apptainer >/dev/null 2>&1 || {
    echo "apptainer not found (tried 'module load apptainer')" >&2
    return 1
  }
}

require_allocation() {
  if [[ -z "$SWEEP_ACCOUNT" || -z "$SWEEP_PARTITION" ]]; then
    echo "Set SWEEP_ACCOUNT and SWEEP_PARTITION in sweep/jobs/env.sh (see 'mychpc batch')." >&2
    return 1
  fi
  if [[ -z "$SWEEP_QOS" && ( "$(hostname)" == granite* || "$SWEEP_PARTITION" == *granite* || "$SWEEP_PARTITION" == rai* ) ]]; then
    echo "Granite jobs need a QOS: set SWEEP_QOS in sweep/jobs/env.sh (e.g. rai-gpu-grn; see 'mychpc batch')." >&2
    return 1
  fi
}
