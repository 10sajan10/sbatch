#!/usr/bin/env bash
# Run the whole sweep on ONE machine, no Slurm: caption -> embed -> pack -> score.
# Use it on a workstation with a GPU and an already-running OpenAI-compatible VLM
# server (Ollama by default). Every stage resumes, so re-running continues.
#
#   export SWEEP_ROOT=~/imsearch-runs SWEEP_CONFIG=$PWD/sweep/sweep_ollama.json
#   sweep/jobs/run_local.sh                    # everything in the config
#   sweep/jobs/run_local.sh --max-images 20    # quick test: 20 images per caption set
#   ENDPOINT=http://127.0.0.1:8000/v1 sweep/jobs/run_local.sh    # a vLLM server instead
#
# Before the first run: sweep/jobs/setup_env.sh venv data models check
# (with the same SWEEP_ROOT and SWEEP_CONFIG), and `ollama pull` every tag listed
# under "captioners" in the config.
set -euo pipefail
SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export SWEEP_DIR
source "${SWEEP_DIR}/jobs/env.sh"
cd "$SWEEP_HOME"

ENDPOINT="${ENDPOINT:-http://127.0.0.1:11434/v1}"
CONCURRENCY="${LOCAL_CONCURRENCY:-4}"     # Ollama: match OLLAMA_NUM_PARALLEL on the server
EXTRA=("$@")
mkdir -p "${SWEEP_ROOT}/logs"
LOG="${SWEEP_ROOT}/logs/run_local-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

[[ -x "$PYTHON" ]] || { echo "No venv at $VENV_DIR; run sweep/jobs/setup_env.sh venv first" >&2; exit 1; }
curl --silent --fail "${ENDPOINT%/}/models" >/dev/null || {
  echo "No OpenAI-compatible server at $ENDPOINT. Start it (e.g. 'ollama serve') and retry." >&2; exit 1; }

mapfile -t CAPTIONERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list captioners)
mapfile -t EMBEDDERS  < <("$PYTHON" "${SWEEP_DIR}/common.py" list embedders)
echo "[$(date -Is)] config: $SWEEP_CONFIG"
echo "captioners: ${CAPTIONERS[*]}"
echo "embedders:  ${EMBEDDERS[*]}"
echo "endpoint:   $ENDPOINT (concurrency $CONCURRENCY)"
echo "output:     $SWEEP_ROOT   log: $LOG"

status=0
for captioner in "${CAPTIONERS[@]}"; do
  echo "[$(date -Is)] == caption ${captioner}"
  "$PYTHON" "${SWEEP_DIR}/caption.py" --captioner "$captioner" --endpoint "$ENDPOINT" \
      --concurrency "$CONCURRENCY" "${EXTRA[@]}" || status=1
done

if [[ " ${EXTRA[*]} " == *" --max-images "* ]]; then
  echo "[$(date -Is)] test run done. Check captions:  head -n 3 ${SWEEP_ROOT}/captions/*__long.jsonl"
  exit "$status"
fi

export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
for embedder in "${EMBEDDERS[@]}"; do
  echo "[$(date -Is)] == embed ${embedder} (images + captions)"
  "$PYTHON" "${SWEEP_DIR}/embed.py" --embedder "$embedder" || status=1
  "$PYTHON" "${SWEEP_DIR}/pack.py" --embedders "$embedder" || status=1
  "$PYTHON" "${SWEEP_DIR}/evaluate_npz.py" --embedders "$embedder" || status=1
done
echo "[$(date -Is)] done (status $status). NPZs: ${SWEEP_ROOT}/npz  scores: ${SWEEP_ROOT}/results/sweep_summary.csv"
exit "$status"
