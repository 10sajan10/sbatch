#!/usr/bin/env bash
# Run one sweep stage on the Jetson AGX Thor, inside the sweep container, with
# the GPU passed through the way this node requires (Podman via `docker`).
#
#   sweep/jobs/thor_run.sh embed.py --embedder mobileclip2-s2 --images
#   sweep/jobs/thor_run.sh caption.py --captioner gemma3-4b \
#       --endpoint http://127.0.0.1:8000/v1 --served-name gemma-3-4b-it --concurrency 1
#   sweep/jobs/thor_run.sh load_index.py --npz sweep/runs/npz/gemma3-4b__short__dfn5b.npz \
#       --backend milvus --path sweep/runs/db/milvus-short --probe 200
#
# Paths inside the container: repo at /work, ~/models at /models (read-only).
# Outputs land in sweep/runs/ (gitignored) unless SWEEP_ROOT says otherwise.
# Build the image first: see sweep/docker/Dockerfile.thor.
set -euo pipefail
SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="$(cd -- "${SWEEP_DIR}/.." && pwd)"
IMAGE="${SWEEP_THOR_IMAGE:-localhost/imsearch-sweep:dev}"
MODELS_DIR="${MODELS_DIR:-${HOME}/models}"
SCRIPT="${1:?usage: thor_run.sh <caption.py|embed.py|pack.py|evaluate_npz.py|load_index.py> [args]}"
shift

exec docker run --rm \
  --device nvidia.com/gpu=all \
  --network host \
  -v "${REPO_DIR}:/work" \
  -v "${MODELS_DIR}:/models:ro" \
  -e MODELS_DIR=/models \
  -e SWEEP_ROOT="${SWEEP_ROOT:-/work/sweep/runs}" \
  -e SWEEP_CONFIG="${SWEEP_CONFIG:-/work/sweep/sweep.json}" \
  -e HF_HOME=/models/hf-cache \
  -e HF_HUB_OFFLINE=1 \
  -e TRANSFORMERS_OFFLINE=1 \
  -w /work \
  "$IMAGE" \
  python3 "sweep/${SCRIPT}" "$@"
