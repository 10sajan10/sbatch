#!/usr/bin/env bash
# Caption the benchmark images with a REMOTE Ollama server and keep only the captions.
# Run it on the machine that has the images (e.g. CHPC); the GPU machine only runs
# Ollama and stores nothing. Images are sent one request at a time (resized to <=1024
# px JPEG) and never copied to the Ollama host.
#
#   export OLLAMA_URL=http://titan-host:11434      # or http://127.0.0.1:11434 through an SSH tunnel
#   sweep/jobs/caption_remote.sh --max-images 20   # quick test: 20 images per model x length
#   sweep/jobs/caption_remote.sh                   # everything; resumes where it stopped
#
# Models and lengths come from $SWEEP_CONFIG (default sweep/sweep_ollama.json).
# Output: $SWEEP_ROOT/captions/<captioner>__<length>.jsonl (+ .meta.json), then
# captions.sqlite and captions.parquet with every caption in one table.
set -euo pipefail
SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export SWEEP_DIR
export SWEEP_CONFIG="${SWEEP_CONFIG:-${SWEEP_DIR}/sweep_ollama.json}"
source "${SWEEP_DIR}/jobs/env.sh"
cd "$SWEEP_HOME"

OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434}"
CONCURRENCY="${CAPTION_CONCURRENCY_REMOTE:-4}"   # match OLLAMA_NUM_PARALLEL on the Ollama host
mkdir -p "${SWEEP_ROOT}/logs"
LOG="${SWEEP_ROOT}/logs/caption_remote-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

[[ -x "$PYTHON" ]] || { echo "No venv at $VENV_DIR (run sweep/jobs/setup_env.sh venv)" >&2; exit 1; }
if ! curl --silent --fail --max-time 10 "${OLLAMA_URL%/}/api/version" >/dev/null; then
  echo "Cannot reach Ollama at $OLLAMA_URL. Check OLLAMA_URL, that 'ollama serve' listens on the" >&2
  echo "network (OLLAMA_HOST=0.0.0.0) or that your SSH tunnel is up." >&2
  exit 1
fi
installed="$(curl --silent "${OLLAMA_URL%/}/api/tags")"

mapfile -t CAPTIONERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list captioners)
echo "[$(date -Is)] Ollama $OLLAMA_URL ($(curl --silent "${OLLAMA_URL%/}/api/version"))"
echo "config:     $SWEEP_CONFIG"
echo "captioners: ${CAPTIONERS[*]}"
echo "lengths:    $("$PYTHON" "${SWEEP_DIR}/common.py" list variants | tr '\n' ' ')"
echo "output:     ${SWEEP_ROOT}/captions   log: $LOG"

missing=0
for captioner in "${CAPTIONERS[@]}"; do
  tag="$("$PYTHON" -c "import json,sys; print(json.load(open(sys.argv[1]))['captioners'][sys.argv[2]]['served_name'])" "$SWEEP_CONFIG" "$captioner")"
  if ! "$PYTHON" -c 'import json,sys; tags={m.get(k) for m in json.loads(sys.argv[1]).get("models",[]) for k in ("name","model")}; sys.exit(0 if sys.argv[2] in tags or sys.argv[2]+":latest" in tags else 1)' "$installed" "$tag"; then
    echo "MISSING on the Ollama host: ${tag} (run 'ollama pull ${tag}' there)" >&2
    missing=1
  fi
done
[[ "$missing" == 0 ]] || exit 1

status=0
for captioner in "${CAPTIONERS[@]}"; do
  echo "[$(date -Is)] == ${captioner}"
  "$PYTHON" "${SWEEP_DIR}/caption.py" --captioner "$captioner" --endpoint "$OLLAMA_URL" \
      --concurrency "$CONCURRENCY" "$@" || status=1
done
"$PYTHON" "${SWEEP_DIR}/export_captions.py" || status=1
echo "[$(date -Is)] done (status $status)"
exit "$status"
