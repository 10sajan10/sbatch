#!/usr/bin/env bash
# Submit the whole sweep as Slurm jobs with dependencies:
#
#   caption.slurm <captioner>      one per enabled captioner (all variants)  ─┐
#   embed_images.slurm <embedder>  one per enabled embedder, in parallel     ─┼─> finalize.slurm <embedder>
#                                                                             ┘   (after all of the above)
#
#   sweep/jobs/submit_sweep.sh                 # submit everything
#   sweep/jobs/submit_sweep.sh --dry-run       # print the sbatch commands only
#   sweep/jobs/submit_sweep.sh --smoke 20      # caption jobs only, 20 images each (GPU smoke test)
#   sweep/jobs/submit_sweep.sh --smoke 20 --dry-run
#
# Smoke-test captions land in the real caption files; the full run keeps them and
# resumes from image 21 (same model, prompt and settings, temperature 0).
#
# finalize uses afterany, so one failed caption job does not block the rest:
# incomplete caption sets are skipped and reported, and you resubmit just them.
set -euo pipefail
SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export SWEEP_DIR
source "${SWEEP_DIR}/jobs/env.sh"
require_allocation

DRY_RUN=0
SMOKE=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY_RUN=1; shift ;;
    --smoke) SMOKE="${2:?--smoke needs an image count, e.g. --smoke 20}"; shift 2 ;;
    *) echo "unknown option: $1 (use --dry-run and/or --smoke N)" >&2; exit 2 ;;
  esac
done
[[ -x "$PYTHON" ]] || { echo "No venv at $VENV_DIR; run sweep/jobs/setup_env.sh first" >&2; exit 1; }
[[ -f "$VLLM_SIF" ]] || { echo "No vLLM image at $VLLM_SIF; run sweep/jobs/setup_env.sh container" >&2; exit 1; }
mkdir -p "${SWEEP_ROOT}/logs"

SBATCH=(sbatch --parsable --account "$SWEEP_ACCOUNT" --partition "$SWEEP_PARTITION"
        --gres "$SWEEP_GRES" --export ALL --chdir "$SWEEP_HOME"
        --output "${SWEEP_ROOT}/logs/%x-%j.out")
[[ -n "$SWEEP_QOS" ]] && SBATCH+=(--qos "$SWEEP_QOS")

submit() {  # submit <args...>; echoes the job id (or a placeholder in dry-run mode)
  if [[ "$DRY_RUN" == 1 ]]; then
    echo "${SBATCH[*]} $*" >&2
    echo "DRY$RANDOM"
  else
    "${SBATCH[@]}" "$@"
  fi
}

mapfile -t CAPTIONERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list captioners)
mapfile -t EMBEDDERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list embedders)
echo "captioners: ${CAPTIONERS[*]}"
echo "variants:   $("$PYTHON" "${SWEEP_DIR}/common.py" list variants | tr '\n' ' ')"
echo "embedders:  ${EMBEDDERS[*]}"
echo "output:     ${SWEEP_ROOT}"

smoke_args=()
[[ "$SMOKE" != 0 ]] && smoke_args=(--max-images "$SMOKE")
caption_jobs=()
for captioner in "${CAPTIONERS[@]}"; do
  job=$(submit --job-name "cap-${captioner}" --time "$SWEEP_TIME_CAPTION" "${SWEEP_DIR}/jobs/caption.slurm" "$captioner" "${smoke_args[@]}")
  caption_jobs+=("$job")
  echo "caption   ${captioner}: ${job}"
done

if [[ "$SMOKE" != 0 ]]; then
  echo "Smoke test submitted. When the jobs finish, check captions with:"
  echo "  head -n 3 ${SWEEP_ROOT}/captions/*.jsonl"
  exit 0
fi

for embedder in "${EMBEDDERS[@]}"; do
  image_job=$(submit --job-name "img-${embedder}" --time "$SWEEP_TIME_IMAGES" "${SWEEP_DIR}/jobs/embed_images.slurm" "$embedder")
  echo "images    ${embedder}: ${image_job}"
  dep_ids=("${caption_jobs[@]}" "$image_job")
  deps="afterany:$(IFS=:; echo "${dep_ids[*]}")"
  final_job=$(submit --job-name "fin-${embedder}" --time "$SWEEP_TIME_FINALIZE" --dependency "$deps" \
              "${SWEEP_DIR}/jobs/finalize.slurm" "$embedder")
  echo "finalize  ${embedder}: ${final_job} (after ${deps#afterany:})"
done
echo "Watch with: squeue -u \$USER ; logs in ${SWEEP_ROOT}/logs"
echo "Results:    ${SWEEP_ROOT}/results/sweep_summary.csv"
