#!/usr/bin/env bash
# Submit the whole sweep as Slurm jobs with dependencies:
#
#   caption.slurm <captioner>      one per enabled captioner (all variants)  ─┐
#   embed_images.slurm <embedder>  one per enabled embedder, in parallel     ─┼─> finalize.slurm <embedder>
#                                                                             ┘   (after all of the above)
#
#   sweep/jobs/submit_sweep.sh             # submit
#   sweep/jobs/submit_sweep.sh --dry-run   # print the sbatch commands only
#
# finalize uses afterany, so one failed caption job does not block the rest:
# incomplete caption sets are skipped and reported, and you resubmit just them.
set -euo pipefail
SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export SWEEP_DIR
source "${SWEEP_DIR}/jobs/env.sh"
require_allocation

DRY_RUN=0
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=1
[[ -x "$PYTHON" ]] || { echo "No venv at $VENV_DIR; run sweep/jobs/setup_env.sh first" >&2; exit 1; }
[[ -f "$VLLM_SIF" ]] || { echo "No vLLM image at $VLLM_SIF; run sweep/jobs/setup_env.sh container" >&2; exit 1; }
mkdir -p "${SWEEP_ROOT}/logs"

SBATCH=(sbatch --parsable --account "$SWEEP_ACCOUNT" --partition "$SWEEP_PARTITION"
        --gres "$SWEEP_GRES" --export ALL --chdir "$REPO_DIR"
        --output "${SWEEP_ROOT}/logs/%x-%j.out")
[[ -n "$SWEEP_QOS" ]] && SBATCH+=(--qos "$SWEEP_QOS")

submit() {  # submit <args...>; echoes the job id (or a placeholder in dry-run mode)
  if [[ "$DRY_RUN" == 1 ]]; then
    echo "${SBATCH[*]} $*" >&2
    echo "DRY$RANDOM"
  else
    "${SBATCH[@]}" "$@"
  fi
}

mapfile -t CAPTIONERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list captioners)
mapfile -t EMBEDDERS < <("$PYTHON" "${SWEEP_DIR}/common.py" list embedders)
echo "captioners: ${CAPTIONERS[*]}"
echo "variants:   $("$PYTHON" "${SWEEP_DIR}/common.py" list variants | tr '\n' ' ')"
echo "embedders:  ${EMBEDDERS[*]}"
echo "output:     ${SWEEP_ROOT}"

caption_jobs=()
for captioner in "${CAPTIONERS[@]}"; do
  job=$(submit --job-name "cap-${captioner}" "${SWEEP_DIR}/jobs/caption.slurm" "$captioner")
  caption_jobs+=("$job")
  echo "caption   ${captioner}: ${job}"
done

for embedder in "${EMBEDDERS[@]}"; do
  image_job=$(submit --job-name "img-${embedder}" "${SWEEP_DIR}/jobs/embed_images.slurm" "$embedder")
  echo "images    ${embedder}: ${image_job}"
  dep_ids=("${caption_jobs[@]}" "$image_job")
  deps="afterany:$(IFS=:; echo "${dep_ids[*]}")"
  final_job=$(submit --job-name "fin-${embedder}" --dependency "$deps" \
              "${SWEEP_DIR}/jobs/finalize.slurm" "$embedder")
  echo "finalize  ${embedder}: ${final_job} (after ${deps#afterany:})"
done
echo "Watch with: squeue -u \$USER ; logs in ${SWEEP_ROOT}/logs"
echo "Results:    ${SWEEP_ROOT}/results/sweep_summary.csv"
