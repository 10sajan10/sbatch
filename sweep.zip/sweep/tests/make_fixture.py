#!/usr/bin/env python3
"""Build a tiny synthetic benchmark in the real on-disk layout, for dry runs.

Two datasets (cloudbench-style ids and inquire-small-style ids, so both id
schemes are exercised). Each image is a solid colour from a small palette; each
query names one colour and its relevant images are the ones in that colour. The
fake captioner (fake_openai_server.py) reads the colour back from the pixels, so
caption-based legs can find the right images while the fake image vectors are
random. A correct pipeline therefore scores caption/BM25 fusions well above
image_only, which the dry run checks.

    python3 sweep/tests/make_fixture.py --out /tmp/sweep-fixture
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
from PIL import Image, ImageDraw

PALETTE = {
    "red": (200, 30, 30), "green": (30, 170, 60), "blue": (40, 60, 200),
    "yellow": (230, 210, 40), "purple": (130, 50, 160), "orange": (240, 130, 20),
}


def build(out: Path, images_per_colour: int) -> None:
    datasets = {
        "cloudbench": ("image_id", "query_text", "relevance_label", lambda n: f"frames/img_{n:04d}"),
        "inquire-small": ("inat24_image_id", "query", "relevant", lambda n: f"{100000 + n}"),
    }
    for dataset, (id_column, text_column, relevance_column, make_id) in datasets.items():
        images = []
        for colour_index, (colour, rgb) in enumerate(PALETTE.items()):
            for copy in range(images_per_colour):
                number = colour_index * images_per_colour + copy
                image_id = make_id(number)
                path = out / "image" / dataset / f"{image_id}.jpg"
                path.parent.mkdir(parents=True, exist_ok=True)
                canvas = Image.new("RGB", (320, 240), rgb)
                ImageDraw.Draw(canvas).ellipse((40 + copy * 7, 40, 140 + copy * 7, 140), outline=(255, 255, 255))
                canvas.save(path, quality=92)
                images.append((image_id, colour))
        rows = {id_column: [], "query_id": [], text_column: [], relevance_column: []}
        for query_number, colour in enumerate(PALETTE):
            for image_id, image_colour in images:
                rows[id_column].append(int(image_id) if id_column == "inat24_image_id" else image_id)
                rows["query_id"].append(f"q{query_number}")
                rows[text_column].append(f"a {colour} scene")
                rows[relevance_column].append(1 if image_colour == colour else 0)
        data_dir = out / "datasets" / dataset / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        pq.write_table(pa.table(rows), data_dir / "test-00000-of-00001.parquet")
        print(f"{dataset}: {len(images)} images, {len(PALETTE)} queries -> {out}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--images-per-colour", type=int, default=5)
    args = parser.parse_args()
    build(args.out, args.images_per_colour)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
