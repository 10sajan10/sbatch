#!/usr/bin/env python3
"""A stand-in for vLLM's OpenAI-compatible server, for dry runs without a GPU.

POST /v1/chat/completions returns a deterministic "caption" naming the image's
dominant palette colour (see make_fixture.py), padded with filler words, and
honours max_tokens the way a real server does: output is cut at the cap and
finish_reason becomes "length". GET /health and /v1/models answer like vLLM.
POST /api/generate and GET /api/version answer like Ollama's native API.

    python3 sweep/tests/fake_openai_server.py --port 18000
"""

from __future__ import annotations

import argparse
import base64
import io
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PIL import Image

PALETTE = {
    "red": (200, 30, 30), "green": (30, 170, 60), "blue": (40, 60, 200),
    "yellow": (230, 210, 40), "purple": (130, 50, 160), "orange": (240, 130, 20),
}
FILLER = ("the scene shows a calm outdoor view with soft light and a simple round outline near "
          "the upper left corner while the rest of the frame stays plain and evenly lit").split()


def dominant_colour(data_uri: str) -> str:
    raw = base64.b64decode(data_uri.split(",", 1)[1])
    with Image.open(io.BytesIO(raw)) as image:
        pixel = image.convert("RGB").resize((1, 1)).getpixel((0, 0))
    return min(PALETTE, key=lambda name: sum((a - b) ** 2 for a, b in zip(PALETTE[name], pixel)))


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args) -> None:  # keep test output quiet
        return

    def reply(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path == "/health":
            self.reply({})
        elif self.path == "/v1/models":
            self.reply({"data": [{"id": self.server.model_name}]})
        elif self.path == "/api/tags":
            self.reply({"models": [{"name": self.server.model_name, "model": self.server.model_name}]})
        elif self.path in ("/version", "/api/version"):
            self.reply({"version": "fake-0"})
        else:
            self.reply({"error": "not found"}, 404)

    def do_POST(self) -> None:
        request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/api/generate":  # Ollama native
            image = "data:image/jpeg;base64," + request["images"][0]
            prompt = request["prompt"]
            max_tokens = request.get("options", {}).get("num_predict", 64)
        else:
            content = request["messages"][0]["content"]
            image = next(part for part in content if part["type"] == "image_url")["image_url"]["url"]
            prompt = next(part for part in content if part["type"] == "text")["text"]
            max_tokens = request.get("max_tokens", 64)
        colour = dominant_colour(image)
        if "keywords" in prompt.lower():
            words = f"{colour}, plain background, round outline, outdoor, soft light, calm, simple".split()
        else:
            words = [colour.capitalize(), "scene."] + (FILLER * 20)
        budget = max(1, int(max_tokens / 1.16))
        finish = "length" if len(words) > budget else "stop"
        text = " ".join(words[:budget])
        if finish == "stop" and not text.endswith("."):
            text += "."
        if self.path == "/api/generate":
            self.reply({"model": request["model"], "response": text, "done": True, "done_reason": finish,
                        "prompt_eval_count": 300, "eval_count": min(len(words), budget)})
            return
        self.reply({
            "choices": [{"index": 0, "finish_reason": finish,
                         "message": {"role": "assistant", "content": text}}],
            "usage": {"prompt_tokens": 300, "completion_tokens": min(len(words), budget),
                      "total_tokens": 300 + min(len(words), budget)},
        })


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=18000)
    parser.add_argument("--model-name", default="fake-captioner")
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.model_name = args.model_name
    print(f"fake OpenAI server on http://127.0.0.1:{args.port}/v1", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
