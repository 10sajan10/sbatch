#!/usr/bin/env python3
"""Ten-second sanity check of real embedders before a long embedding job.

Any working CLIP-family model can tell solid colours apart zero-shot. Each
embedder sees six solid-colour images and six "a photo of the colour X" texts;
the check passes when vectors are unit-length, image/text dimensions agree, and
at least 5 of 6 images pick their own colour. A broken preprocessing,
projection, or normalisation path fails this immediately instead of after
hours of embedding.

    python3 sweep/tests/smoke_embedders.py                    # every enabled embedder
    python3 sweep/tests/smoke_embedders.py --embedders dfn5b
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from sweep.common import load_config, pick  # noqa: E402
from sweep.embedders import load_embedder  # noqa: E402

COLOURS = {"red": (220, 20, 20), "green": (20, 180, 40), "blue": (20, 40, 220),
           "yellow": (240, 220, 20), "black": (5, 5, 5), "white": (250, 250, 250)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--embedders", nargs="+")
    parser.add_argument("--models-dir", type=Path)
    parser.add_argument("--device")
    args = parser.parse_args()
    config = load_config(args.config)

    images = [Image.new("RGB", (400, 300), rgb) for rgb in COLOURS.values()]
    texts = [f"a photo of the colour {name}" for name in COLOURS]
    failures = 0
    for name, spec in pick(config["embedders"], args.embedders, "embedder").items():
        if spec["kind"] == "fake":
            continue
        embedder = load_embedder(name, spec, models_dir=args.models_dir, device=args.device)
        image_vectors = embedder.embed_images(images)
        text_vectors = embedder.embed_texts(texts, query=True)
        norms = np.concatenate([np.linalg.norm(image_vectors, axis=1), np.linalg.norm(text_vectors, axis=1)])
        correct = int((np.argmax(image_vectors @ text_vectors.T, axis=1) == np.arange(len(texts))).sum())
        tokens = embedder.count_text_tokens(["one two three four five"])
        ok = (image_vectors.shape == text_vectors.shape and np.allclose(norms, 1.0, atol=1e-3)
              and correct >= len(texts) - 1)
        failures += not ok
        print(f"{'PASS' if ok else 'FAIL'} {name}: dim={image_vectors.shape[1]} device={embedder.device} "
              f"colour match {correct}/{len(texts)} norms {norms.min():.4f}-{norms.max():.4f} "
              f"tokens('one two three four five')={tokens}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
