#!/usr/bin/env python3
"""Check that evaluate_npz.py ranks exactly like scripts/benchmark_search.py.

For every query of every dataset in one packed NPZ, and every fusion in the
config, this compares the top-k image IDs from evaluate_npz.fused_order with
the IDs returned by benchmark_search.dual_vector_search (the function behind
the published edge_v2/edge_v3 numbers), using the cached query vectors that
evaluate_npz.py wrote. Any difference is printed and fails the check.

    python3 sweep/tests/check_fusion_parity.py --npz runs/npz/gemma3-4b__short__dfn5b.npz
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "scripts"))
from sweep.common import Layout, default_dataset_dir, load_config  # noqa: E402
from sweep.evaluate_npz import fused_order, load_npz  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--npz", type=Path, required=True)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--dataset-dir", type=Path)
    args = parser.parse_args()

    from benchmark_search import (  # noqa: PLC0415
        BenchmarkProfile, LocalBM25, dual_vector_search, load_ground_truth, relative_score,
    )

    config = load_config(args.config)
    layout = Layout(args.root)
    k = int(config["evaluation"]["top_k"])
    metadata, image_vectors, caption_vectors = load_npz(args.npz)
    cache = layout.query_vectors(str(metadata["embedder"]))
    if not cache.exists():
        raise SystemExit(f"{cache} not found; run evaluate_npz.py first")
    with np.load(cache) as archive:
        query_meta = json.loads(bytes(archive["meta"]).decode("utf-8"))["queries"]
        query_vectors = {dataset: archive[f"vectors__{dataset}"] for dataset in query_meta}

    records = metadata["records"]
    checked = mismatched = 0
    for dataset in config["datasets"]:
        queries, _corpus = load_ground_truth(args.dataset_dir or default_dataset_dir(), dataset)
        positions = [i for i, record in enumerate(records) if record["dataset"] == dataset]
        image_ids = [str(records[i]["image_id"]) for i in positions]
        image_matrix, caption_matrix = image_vectors[positions], caption_vectors[positions]
        bm25 = LocalBM25([str(records[i]["caption"]) for i in positions])
        rows = {query_id: row for row, (query_id, _text) in enumerate(query_meta[dataset])}
        for query_id, group in sorted(queries.items()):
            if not group.relevant:
                continue
            vector = query_vectors[dataset][rows[query_id]]
            legs = {"image": relative_score(image_matrix @ vector),
                    "caption": relative_score(caption_matrix @ vector),
                    "bm25": relative_score(bm25.scores(group.query_text))}
            for fusion, weights in config["fusions"].items():
                ours = [image_ids[p] for p in fused_order(weights, legs, k)]
                profile = BenchmarkProfile(
                    version="parity", database_engine="qdrant", weaviate_url="", collection="",
                    image_vector="image", caption_vector="caption",
                    image_weight=float(weights.get("image", 0)), caption_weight=float(weights.get("caption", 0)),
                    bm25_weight=float(weights.get("bm25", 0)), bm25_properties=["caption"],
                    method="", caption_model="", embed_model="", query_task=None,
                )
                theirs = [image_id for _ds, image_id, _vec in dual_vector_search(
                    profile, dataset, group.query_text, vector.tolist(), image_ids,
                    image_matrix, caption_matrix, bm25, k)]
                checked += 1
                if ours != theirs:
                    mismatched += 1
                    print(f"MISMATCH {dataset} {query_id} {fusion}:\n  ours   {ours}\n  theirs {theirs}")
    print(f"checked {checked} rankings, {mismatched} mismatched")
    return 1 if mismatched else 0


if __name__ == "__main__":
    raise SystemExit(main())
