#!/usr/bin/env bash
# CPU-only, end-to-end check of the sweep: synthetic benchmark, fake captioner
# server, fake embedder. Run it on a login node before spending GPU hours.
#
#   sweep/tests/dry_run.sh                 # temp directory, cleaned up after
#   sweep/tests/dry_run.sh /tmp/sweep-dry  # keep the outputs for inspection
#
# Uses $PYTHON (default python3), which needs numpy, pillow and pyarrow:
# the sweep venv from jobs/setup_env.sh has them.
# If qdrant-client or pymilvus are installed, the load stage is tested too.
set -euo pipefail

SWEEP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SWEEP_HOME="$(cd -- "${SWEEP_DIR}/.." && pwd)"
PYTHON="${PYTHON:-python3}"
if [[ $# -ge 1 ]]; then
  WORK="$1"
  mkdir -p "$WORK"
  KEEP=1
else
  WORK="$(mktemp -d)"
  KEEP=0
fi

PORT="$("$PYTHON" -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')"
"$PYTHON" "${SWEEP_DIR}/tests/fake_openai_server.py" --port "$PORT" &
SERVER_PID=$!
cleanup() {
  kill "$SERVER_PID" 2>/dev/null || true
  if [[ "$KEEP" == 0 ]]; then rm -rf "$WORK"; fi
}
trap cleanup EXIT

export SWEEP_CONFIG="${SWEEP_DIR}/tests/dry_run.json"
export SWEEP_ROOT="${WORK}/runs"
export DATASET_DIR="${WORK}/datasets"
export IMAGE_DIR="${WORK}/image"
export SWEEP_DEVICE=cpu
cd "$SWEEP_HOME"

"$PYTHON" "${SWEEP_DIR}/tests/make_fixture.py" --out "$WORK"
for _ in $(seq 1 50); do
  curl --silent --fail "http://127.0.0.1:${PORT}/health" >/dev/null && break
  sleep 0.2
done

echo "== caption"
"$PYTHON" sweep/caption.py --captioner fake --endpoint "http://127.0.0.1:${PORT}/v1" --concurrency 4
echo "== embed"
"$PYTHON" sweep/embed.py --embedder fake
echo "== pack"
"$PYTHON" sweep/pack.py
echo "== evaluate"
"$PYTHON" sweep/evaluate_npz.py

echo "== check"
"$PYTHON" - "$SWEEP_ROOT/results/sweep_summary.csv" <<'EOF'
import csv, sys
rows = [r for r in csv.DictReader(open(sys.argv[1])) if r["dataset"] == "overall"]
by = {}
for r in rows:
    by.setdefault(r["fusion"], []).append(float(r["composite"]))
mean = {k: sum(v) / len(v) for k, v in by.items()}
print({k: round(v, 3) for k, v in sorted(mean.items())})
# Fake image vectors are random; captions name the colour. A correct pipeline
# must therefore let the caption legs find the right images almost perfectly,
# well above image-only.
assert mean["bm25_only"] >= 0.9, mean
assert mean["caption_only"] >= 0.9, mean
assert mean["hybrid_60_25_15"] > mean["image_only"], mean
print("dry run: scores behave as expected")
EOF

NPZ="$(ls "$SWEEP_ROOT"/npz/*__short__fake.npz | head -1)"
if "$PYTHON" -c "import pymilvus, milvus_lite" 2>/dev/null; then
  echo "== load: milvus lite"
  "$PYTHON" sweep/load_index.py --npz "$NPZ" --backend milvus --path "$WORK/db/milvus" --recreate --probe 5 --k 5
fi
if "$PYTHON" -c "import qdrant_client" 2>/dev/null; then
  echo "== load: qdrant (embedded)"
  "$PYTHON" sweep/load_index.py --npz "$NPZ" --backend qdrant --path "$WORK/db/qdrant" --recreate --probe 5 --k 5
fi
echo "dry run passed; outputs in ${WORK}$([[ $KEEP == 0 ]] && echo ' (deleted)')"
