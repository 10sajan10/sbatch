#!/usr/bin/env python3
"""Stage 4: score every packed NPZ on the benchmark queries, for every fusion in sweep.json.

Scoring needs no database. It uses exact (brute-force) cosine over the stored
vectors plus BM25 over the stored captions, with the SAME functions as
scripts/benchmark_search.py: load_ground_truth, LocalBM25, relative_score and
evaluate_query are imported from there, and the fusion below reproduces its
dual_vector_search ranking (per-leg min-max over the isolated dataset, weighted
sum, stable sort). So sweep numbers are directly comparable to the edge_v2 and
edge_v3 results already in benchmarking/results/.

Benchmark queries are embedded once per embedder and cached next to that
embedder's vectors, because they are identical for every captioner and variant.

Outputs, per config and fusion, mirror benchmark_search.py:
    results/<config>/<fusion>/query_eval_metrics_isolated.csv
    results/<config>/<fusion>/summary_isolated.csv
plus one table across everything evaluated so far:
    results/sweep_summary.csv

    python3 sweep/evaluate_npz.py                       # every NPZ under npz/
    python3 sweep/evaluate_npz.py --embedders dfn5b
    python3 sweep/evaluate_npz.py --collect-only        # just rebuild sweep_summary.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import (  # noqa: E402
    Layout,
    default_dataset_dir,
    load_config,
    pick,
    write_json_atomic,
)

SUMMARY_FIELDS = [
    "config_name", "captioner", "caption_variant", "embedder", "fusion",
    "w_image", "w_caption", "w_bm25", "dataset", "num_queries_evaluated",
    "MRR", "Success@K", "NDCG@K", "Precision@K", "Recall@K", "composite",
    "caption_completion_tokens_mean", "caption_words_mean",
    "fraction_captions_over_text_limit", "vector_dimension", "k",
]


def import_benchmark_functions():
    """The original evaluator's metric code, vendored verbatim in sweep/metrics.py."""
    from sweep.metrics import (  # noqa: PLC0415
        LocalBM25,
        evaluate_query,
        load_ground_truth,
        relative_score,
    )
    return load_ground_truth, LocalBM25, relative_score, evaluate_query


def fused_order(weights: dict[str, float], legs: dict[str, np.ndarray], k: int) -> np.ndarray:
    """Top-k positions, exactly as benchmark_search.dual_vector_search ranks them:
    weighted sum of per-leg min-max scores in image, caption, bm25 order, then a
    stable descending sort (parity checked: 0 mismatches in 144 rankings)."""
    combined = (float(weights.get("image", 0)) * legs["image"]
                + float(weights.get("caption", 0)) * legs["caption"]
                + float(weights.get("bm25", 0)) * legs["bm25"])
    return np.argsort(-combined, kind="stable")[:k]


def load_npz(path: Path) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    with np.load(path) as archive:
        metadata = json.loads(bytes(archive["metadata"]).decode("utf-8"))
        return metadata, archive["image_vectors"].astype(np.float32), archive["caption_vectors"].astype(np.float32)


def query_vectors_for(embedder_name: str, spec: dict[str, Any], layout: Layout, datasets: list[str],
                      ground_truth: dict[str, dict[str, Any]], args: argparse.Namespace) -> dict[str, np.ndarray]:
    """Return {dataset: matrix aligned to sorted query ids}, embedding at most once."""
    cache = layout.query_vectors(embedder_name)
    wanted = {dataset: [[query_id, ground_truth[dataset][query_id].query_text]
                        for query_id in sorted(ground_truth[dataset])] for dataset in datasets}
    if cache.exists() and not args.force_queries:
        with np.load(cache) as archive:
            stored = json.loads(bytes(archive["meta"]).decode("utf-8"))
            if (stored.get("model_id") == spec.get("model_id")
                    and all(stored["queries"].get(dataset) == wanted[dataset] for dataset in datasets)):
                return {dataset: archive[f"vectors__{dataset}"] for dataset in datasets}

    from sweep.embedders import load_embedder  # noqa: PLC0415 - heavy import, only when needed

    embedder = load_embedder(embedder_name, spec, models_dir=args.models_dir, device=args.device)
    print(f"[{embedder_name}] embedding benchmark queries on {embedder.device}", flush=True)
    vectors = {}
    for dataset in datasets:
        texts = [text for _query_id, text in wanted[dataset]]
        chunks = [embedder.embed_texts(texts[start:start + 256], query=True)
                  for start in range(0, len(texts), 256)]
        vectors[dataset] = np.concatenate(chunks).astype(np.float32)
    cache.parent.mkdir(parents=True, exist_ok=True)
    temp = cache.with_name(f".{cache.stem}.tmp.npz")
    np.savez(temp, meta=np.frombuffer(json.dumps({
        "model_id": spec.get("model_id"), "embedder": embedder.describe(), "queries": wanted,
    }).encode("utf-8"), dtype=np.uint8), **{f"vectors__{d}": v for d, v in vectors.items()})
    temp.replace(cache)
    return vectors


def evaluate_config(npz_path: Path, config: dict[str, Any], layout: Layout, args: argparse.Namespace,
                    ground_truth: dict[str, dict[str, Any]], corpora: dict[str, set[str]],
                    functions) -> list[dict[str, Any]]:
    _load_ground_truth, LocalBM25, relative_score, evaluate_query = functions
    metadata, image_vectors, caption_vectors = load_npz(npz_path)
    name = str(metadata.get("config_name") or npz_path.stem)
    embedder_name = str(metadata["embedder"])
    spec = config["embedders"].get(embedder_name) or metadata["embedder_spec"]
    datasets = [dataset for dataset in config["datasets"] if dataset in ground_truth]
    k = int(config["evaluation"]["top_k"])
    fusions = pick(config["fusions"], args.fusions, "fusion") if args.fusions else config["fusions"]
    query_vectors = query_vectors_for(embedder_name, spec, layout, datasets, ground_truth, args)

    records = metadata["records"]
    by_dataset: dict[str, list[int]] = {}
    for position, record in enumerate(records):
        by_dataset.setdefault(str(record["dataset"]), []).append(position)

    text_tokens = metadata.get("embedder_text_tokens") or {}
    caption_stats = metadata.get("caption_stats") or {}
    common = {
        "config_name": name,
        "captioner": metadata.get("captioner"),
        "caption_variant": metadata.get("caption_variant"),
        "embedder": embedder_name,
        "caption_completion_tokens_mean": caption_stats.get("completion_tokens_mean"),
        "caption_words_mean": caption_stats.get("words_mean"),
        "fraction_captions_over_text_limit": text_tokens.get("fraction_over_limit"),
        "vector_dimension": metadata.get("vector_dimension", image_vectors.shape[1]),
        "k": k,
    }
    need = {leg: any(float(f.get(leg, 0)) > 0 for f in fusions.values()) for leg in ("image", "caption", "bm25")}
    sums = {fusion: {} for fusion in fusions}
    counts = {fusion: {} for fusion in fusions}
    query_rows: dict[str, list[dict[str, Any]]] = {fusion: [] for fusion in fusions}
    started = time.time()

    for dataset in datasets:
        positions = by_dataset.get(dataset, [])
        image_ids = [str(records[position]["image_id"]) for position in positions]
        if set(image_ids) != corpora[dataset]:
            raise SystemExit(f"{name}/{dataset}: NPZ ids do not match the benchmark corpus "
                             f"({len(set(image_ids))} vs {len(corpora[dataset])})")
        image_matrix = image_vectors[positions]
        caption_matrix = caption_vectors[positions]
        bm25 = LocalBM25([str(records[p]["caption"]) for p in positions]) if need["bm25"] else None
        queries = ground_truth[dataset]
        query_ids = sorted(queries)
        vector_rows = {query_id: row for row, query_id in enumerate(query_ids)}
        if args.max_queries_per_dataset:
            rng = random.Random(args.seed)
            query_ids = sorted(rng.sample(query_ids, min(args.max_queries_per_dataset, len(query_ids))))
        zeros = np.zeros(len(positions), dtype=np.float32)
        for query_id in query_ids:
            group = queries[query_id]
            if not group.relevant:
                continue
            vector = query_vectors[dataset][vector_rows[query_id]]
            legs = {
                "image": relative_score(image_matrix @ vector) if need["image"] else zeros,
                "caption": relative_score(caption_matrix @ vector) if need["caption"] else zeros,
                "bm25": relative_score(bm25.scores(group.query_text)) if bm25 is not None else zeros,
            }
            relevant = {(dataset, image_id) for image_id in group.relevant}
            for fusion, weights in fusions.items():
                order = fused_order(weights, legs, k)
                ranked = [(dataset, image_ids[p], image_matrix[p].tolist()) for p in order]
                metrics = evaluate_query(ranked, relevant, k)
                bucket = sums[fusion].setdefault(dataset, {})
                for key, value in metrics.items():
                    bucket[key] = bucket.get(key, 0.0) + value
                counts[fusion][dataset] = counts[fusion].get(dataset, 0) + 1
                query_rows[fusion].append({"dataset": dataset, "scope": "isolated", "query_id": query_id,
                                           "query_text": group.query_text, **metrics})

    rows: list[dict[str, Any]] = []
    for fusion, weights in fusions.items():
        out_dir = layout.results_dir / name / fusion
        out_dir.mkdir(parents=True, exist_ok=True)
        summary = []
        for dataset in datasets:
            n = counts[fusion].get(dataset, 0)
            if not n:
                continue
            means = {key: value / n for key, value in sums[fusion][dataset].items()}
            summary.append({
                "dataset": dataset, "scope": "isolated", "status": "evaluated", "coverage": 1.0,
                "num_queries_total": len(ground_truth[dataset]), "num_queries_evaluated": n,
                "MRR": round(means["reciprocal_rank"], 4), f"Success@{k}": round(means["hit"], 4),
                f"Precision@{k}": round(means["precision_at_k"], 4),
                f"Recall@{k}": round(means["recall_at_k"], 4), f"NDCG@{k}": round(means["ndcg_at_k"], 4),
            })
            rows.append({**common, "fusion": fusion, "w_image": weights.get("image", 0),
                         "w_caption": weights.get("caption", 0), "w_bm25": weights.get("bm25", 0),
                         "dataset": dataset, "num_queries_evaluated": n,
                         "MRR": means["reciprocal_rank"], "Success@K": means["hit"],
                         "NDCG@K": means["ndcg_at_k"], "Precision@K": means["precision_at_k"],
                         "Recall@K": means["recall_at_k"]})
        evaluated = [row for row in rows if row["fusion"] == fusion and row["dataset"] != "overall"]
        if evaluated:
            overall = {key: float(np.mean([row[key] for row in evaluated]))
                       for key in ("MRR", "Success@K", "NDCG@K", "Precision@K", "Recall@K")}
            rows.append({**common, "fusion": fusion, "w_image": weights.get("image", 0),
                         "w_caption": weights.get("caption", 0), "w_bm25": weights.get("bm25", 0),
                         "dataset": "overall",
                         "num_queries_evaluated": sum(row["num_queries_evaluated"] for row in evaluated),
                         **overall, "composite": 0.5 * overall["MRR"] + 0.5 * overall["Success@K"]})
        write_csv(out_dir / "query_eval_metrics_isolated.csv", query_rows[fusion])
        write_csv(out_dir / "summary_isolated.csv", summary)
        write_json_atomic(out_dir / "sweep_rows.json", [row for row in rows if row["fusion"] == fusion])

    best = [row for row in rows if row["dataset"] == "overall"]
    line = "  ".join(f"{row['fusion']}={row['composite']:.4f}" for row in best)
    print(f"{name}: composite {line} ({time.time() - started:.0f}s)", flush=True)
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    if not rows:
        return
    fields = fields or list(rows[0].keys())
    temp = path.with_name(f".{path.name}.tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def collect(layout: Layout) -> Path | None:
    rows: list[dict[str, Any]] = []
    for path in sorted(layout.results_dir.glob("*/*/sweep_rows.json")):
        rows.extend(json.loads(path.read_text(encoding="utf-8")))
    if not rows:
        return None
    rows.sort(key=lambda row: (row["embedder"], str(row["captioner"]), str(row["caption_variant"]),
                               row["fusion"], row["dataset"] != "overall", row["dataset"]))
    output = layout.results_dir / "sweep_summary.csv"
    write_csv(output, rows, SUMMARY_FIELDS)
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--npz", nargs="+", type=Path, help="Specific files (default: all under npz/).")
    parser.add_argument("--embedders", nargs="+", help="Only NPZs built with these embedders.")
    parser.add_argument("--fusions", nargs="+", help="Subset of sweep.json fusions.")
    parser.add_argument("--dataset-dir", type=Path)
    parser.add_argument("--models-dir", type=Path)
    parser.add_argument("--device")
    parser.add_argument("--max-queries-per-dataset", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--force-queries", action="store_true", help="Re-embed the cached queries.")
    parser.add_argument("--collect-only", action="store_true")
    args = parser.parse_args()

    config = load_config(args.config)
    layout = Layout(args.root)
    if args.collect_only:
        print(f"wrote {collect(layout)}")
        return 0

    paths = args.npz or sorted(layout.npz_dir.glob("*.npz"))
    if args.embedders:
        paths = [path for path in paths if path.stem.rsplit("__", 1)[-1] in set(args.embedders)]
    paths = [path for path in paths if not path.name.startswith(".")]
    if not paths:
        print(f"No NPZ files to evaluate under {layout.npz_dir}")
        return 1

    functions = import_benchmark_functions()
    load_ground_truth = functions[0]
    dataset_dir = args.dataset_dir or default_dataset_dir()
    ground_truth, corpora = {}, {}
    for dataset in config["datasets"]:
        ground_truth[dataset], corpora[dataset] = load_ground_truth(dataset_dir, dataset)
    print(f"Evaluating {len(paths)} NPZ files x {len(args.fusions or config['fusions'])} fusions", flush=True)

    # Group by embedder so each query cache is built once.
    for path in sorted(paths, key=lambda p: (p.stem.rsplit("__", 1)[-1], p.stem)):
        evaluate_config(path, config, layout, args, ground_truth, corpora, functions)
    print(f"wrote {collect(layout)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
