#!/usr/bin/env python3
"""Collect every caption set under $SWEEP_ROOT/captions into one queryable store.

Writes two files with the same rows (one row per image x captioner x length):

  $SWEEP_ROOT/captions/captions.sqlite   indexed; query with sqlite3 or pandas
  $SWEEP_ROOT/captions/captions.parquet  columnar; for pandas / pyarrow / DuckDB

Columns: dataset, image_id, image_path (relative to the image root), captioner,
model, variant, kind, target_words, max_tokens, caption, words,
completion_tokens, prompt_tokens, finish_reason, server_seconds.
Images are referenced by path, never copied.

The per-set JSONL files stay the source of truth (captioning appends to them and
resumes from them); re-run this script any time to refresh the store.

    python3 sweep/export_captions.py
    sqlite3 $SWEEP_ROOT/captions/captions.sqlite \
      "SELECT caption FROM captions WHERE captioner='gemma3-4b-ollama' AND variant='w50' LIMIT 3"
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import Layout, image_relative_path, iter_jsonl, read_json  # noqa: E402

COLUMNS = [
    ("dataset", "TEXT NOT NULL"), ("image_id", "TEXT NOT NULL"), ("image_path", "TEXT NOT NULL"),
    ("captioner", "TEXT NOT NULL"), ("model", "TEXT"), ("variant", "TEXT NOT NULL"),
    ("kind", "TEXT"), ("target_words", "INTEGER"), ("max_tokens", "INTEGER"),
    ("caption", "TEXT NOT NULL"), ("words", "INTEGER"), ("completion_tokens", "INTEGER"),
    ("prompt_tokens", "INTEGER"), ("finish_reason", "TEXT"), ("server_seconds", "REAL"),
]


def collect(layout: Layout) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    sets: list[dict[str, Any]] = []
    for meta_file in sorted(layout.captions_dir.glob("*.meta.json")):
        meta = read_json(meta_file)
        data_file = meta_file.with_name(meta_file.name.replace(".meta.json", ".jsonl"))
        if not data_file.exists():
            continue
        latest: dict[tuple[str, str], dict[str, Any]] = {}
        for row in iter_jsonl(data_file):  # last row wins if an image was re-captioned
            latest[(str(row["dataset"]), str(row["image_id"]))] = row
        for (dataset, image_id), row in sorted(latest.items()):
            rows.append({
                "dataset": dataset, "image_id": image_id,
                "image_path": f"{dataset}/{image_relative_path(image_id)}",
                "captioner": meta.get("captioner"), "model": meta.get("model"),
                "variant": meta.get("variant"), "kind": meta.get("kind"),
                "target_words": meta.get("target_words"), "max_tokens": meta.get("max_tokens"),
                "caption": row.get("caption", ""), "words": row.get("words"),
                "completion_tokens": row.get("completion_tokens"),
                "prompt_tokens": row.get("prompt_tokens"),
                "finish_reason": row.get("finish_reason"),
                "server_seconds": row.get("server_seconds"),
            })
        sets.append({"caption_set": meta.get("caption_set"), "captioner": meta.get("captioner"),
                     "model": meta.get("model"), "variant": meta.get("variant"),
                     "rows": len(latest), "settings": json.dumps(meta, ensure_ascii=False)})
    return rows, sets


def write_sqlite(path: Path, rows: list[dict[str, Any]], sets: list[dict[str, Any]]) -> None:
    temp = path.with_suffix(".sqlite.tmp")
    temp.unlink(missing_ok=True)
    with sqlite3.connect(temp) as db:
        columns = ", ".join(f"{name} {kind}" for name, kind in COLUMNS)
        db.execute(f"CREATE TABLE captions ({columns}, "
                   "PRIMARY KEY (dataset, image_id, captioner, variant))")
        db.execute("CREATE INDEX captions_by_set ON captions (captioner, variant)")
        db.execute("CREATE TABLE caption_sets (caption_set TEXT PRIMARY KEY, captioner TEXT, "
                   "model TEXT, variant TEXT, rows INTEGER, settings TEXT)")
        names = [name for name, _ in COLUMNS]
        db.executemany(f"INSERT INTO captions ({', '.join(names)}) VALUES ({', '.join('?' * len(names))})",
                       [[row[name] for name in names] for row in rows])
        db.executemany("INSERT INTO caption_sets VALUES (?, ?, ?, ?, ?, ?)",
                       [[s["caption_set"], s["captioner"], s["model"], s["variant"], s["rows"], s["settings"]]
                        for s in sets])
    temp.replace(path)


def write_parquet(path: Path, rows: list[dict[str, Any]]) -> bool:
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError:
        print("pyarrow not installed; skipped the Parquet copy", flush=True)
        return False
    table = pa.Table.from_pylist(rows) if rows else pa.table({name: [] for name, _ in COLUMNS})
    temp = path.with_suffix(".parquet.tmp")
    pq.write_table(table, temp, compression="zstd")
    temp.replace(path)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", type=Path, help="Sweep output root (default: $SWEEP_ROOT or sweep/runs).")
    args = parser.parse_args()
    layout = Layout(args.root)
    rows, sets = collect(layout)
    if not sets:
        print(f"No caption sets under {layout.captions_dir}", flush=True)
        return 1
    db_path = layout.captions_dir / "captions.sqlite"
    write_sqlite(db_path, rows, sets)
    parquet = write_parquet(layout.captions_dir / "captions.parquet", rows)
    print(f"{len(rows)} captions from {len(sets)} caption sets", flush=True)
    for s in sets:
        print(f"  {s['caption_set']:<32} {s['rows']:>7} rows", flush=True)
    print(f"wrote {db_path}" + (f" and {db_path.with_suffix('.parquet')}" if parquet else ""), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
