"""Captioner x caption-length x embedder sweep. See sweep/README.md."""
