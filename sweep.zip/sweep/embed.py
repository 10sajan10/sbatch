#!/usr/bin/env python3
"""Stage 2: embed images (once per embedder) and caption sets (once per embedder x caption set).

Image vectors do not depend on the captioner, so each embedder embeds the
~32k benchmark images exactly once and every caption set reuses them. Caption
vectors are embedded per (embedder, captioner, variant).

All arrays follow the canonical record order from sweep/common.py, and each
.npy has a .meta.json with the order fingerprint, model, versions, and (for
captions) token-length statistics against the embedder's text limit. Those
statistics answer "how many captions does a 77-token text encoder truncate?"
directly from the run.

    python3 sweep/embed.py --embedder dfn5b --images
    python3 sweep/embed.py --embedder dfn5b --captions
    python3 sweep/embed.py --embedder fake --images --captions      # dry run
"""

from __future__ import annotations

import argparse
import sys
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sweep.common import (  # noqa: E402
    ImageRecord,
    Layout,
    caption_set_name,
    default_dataset_dir,
    default_image_dir,
    load_caption_rows,
    load_config,
    load_records,
    meta_path,
    package_versions,
    pick,
    read_json,
    records_fingerprint,
    save_npy_atomic,
    write_json_atomic,
)
from sweep.embedders import Embedder, load_embedder  # noqa: E402

VERSIONS = ("torch", "transformers", "open_clip_torch", "timm", "numpy", "pillow")


def up_to_date(path: Path, fingerprint: str, extra: dict[str, Any] | None = None) -> bool:
    meta = meta_path(path)
    if not path.exists() or not meta.exists():
        return False
    recorded = read_json(meta)
    if recorded.get("records_fingerprint") != fingerprint:
        return False
    return all(recorded.get(key) == value for key, value in (extra or {}).items())


def load_rgb(path: Path) -> Image.Image:
    with Image.open(path) as source:
        return source.convert("RGB")


def embed_images(embedder: Embedder, records: list[ImageRecord], batch_size: int,
                 workers: int) -> tuple[np.ndarray, float]:
    batches = [records[start:start + batch_size] for start in range(0, len(records), batch_size)]
    matrix: np.ndarray | None = None
    started = time.time()
    def decode(batch: list[ImageRecord]) -> list[Image.Image]:
        return [load_rgb(record.image_path) for record in batch]

    with ThreadPoolExecutor(max_workers=workers) as pool:
        # Decode a few batches ahead while the GPU works, but never more than
        # `workers` batches at once: pool.map would decode all 32k images up front.
        ahead = deque(pool.submit(decode, batch) for batch in batches[:workers])
        next_batch = len(ahead)
        for index in range(len(batches)):
            images = ahead.popleft().result()
            if next_batch < len(batches):
                ahead.append(pool.submit(decode, batches[next_batch]))
                next_batch += 1
            vectors = embedder.embed_images(images)
            for image in images:
                image.close()
            if matrix is None:
                matrix = np.zeros((len(records), vectors.shape[1]), dtype=np.float32)
            start = index * batch_size
            matrix[start:start + len(vectors)] = vectors
            done = min(start + len(vectors), len(records))
            if (index + 1) % 50 == 0 or done == len(records):
                rate = done / max(time.time() - started, 1e-6)
                print(f"  images {done}/{len(records)} ({rate:.0f}/s)", flush=True)
    assert matrix is not None
    return matrix, time.time() - started


def token_stats(counts: list[int] | None, limit: int | None) -> dict[str, Any]:
    if not counts:
        return {"available": False}
    array = np.asarray(counts)
    stats: dict[str, Any] = {
        "available": True,
        "mean": round(float(array.mean()), 2),
        "p50": int(np.percentile(array, 50)),
        "p95": int(np.percentile(array, 95)),
        "max": int(array.max()),
    }
    if limit:
        stats["limit"] = int(limit)
        stats["fraction_over_limit"] = round(float((array > limit).mean()), 4)
    return stats


def run_images(args: argparse.Namespace, embedder: Embedder, layout: Layout,
               records: list[ImageRecord], fingerprint: str) -> None:
    path = layout.image_vectors(embedder.name)
    if not args.force and up_to_date(path, fingerprint):
        print(f"[{embedder.name}] image vectors up to date: {path}", flush=True)
        return
    print(f"[{embedder.name}] embedding {len(records)} images", flush=True)
    matrix, seconds = embed_images(embedder, records, args.batch_size, args.workers)
    save_npy_atomic(path, matrix)
    write_json_atomic(meta_path(path), {
        "embedder": embedder.describe(),
        "records_fingerprint": fingerprint,
        "count": int(matrix.shape[0]),
        "dimension": int(matrix.shape[1]),
        "batch_size": args.batch_size,
        # Datacenter throughput, for planning only. Edge cost comes from the
        # profiling harness on the device, not from this number.
        "seconds": round(seconds, 1),
        "images_per_second": round(matrix.shape[0] / max(seconds, 1e-6), 2),
        "versions": package_versions(*VERSIONS),
        "written_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    })
    print(f"[{embedder.name}] wrote {path} {matrix.shape}", flush=True)


def run_captions(args: argparse.Namespace, config: dict[str, Any], embedder: Embedder,
                 layout: Layout, records: list[ImageRecord], fingerprint: str) -> int:
    missing_sets = 0
    for captioner in pick(config["captioners"], args.captioners, "captioner"):
        for variant in pick(config["caption_variants"], args.variants, "caption variant"):
            name = caption_set_name(captioner, variant)
            source = layout.caption_file(captioner, variant)
            path = layout.caption_vectors(embedder.name, captioner, variant)
            source_mtime = source.stat().st_mtime if source.exists() else None
            if not args.force and up_to_date(path, fingerprint, {"source_mtime": source_mtime}):
                print(f"[{embedder.name}] {name}: up to date", flush=True)
                continue
            rows = load_caption_rows(source)
            missing = [record.key for record in records if record.key not in rows]
            if missing:
                missing_sets += 1
                print(f"[{embedder.name}] {name}: SKIPPED, {len(missing)} of {len(records)} "
                      f"images have no caption yet (e.g. {missing[0]}). Finish or re-run "
                      "captioning, then re-run this stage.", flush=True)
                continue
            texts = [str(rows[record.key]["caption"]) for record in records]
            started = time.time()
            chunks = []
            for start in range(0, len(texts), args.text_batch_size):
                chunks.append(embedder.embed_texts(texts[start:start + args.text_batch_size]))
            matrix = np.concatenate(chunks).astype(np.float32)
            seconds = time.time() - started
            counts = embedder.count_text_tokens(texts)
            completion = [rows[record.key].get("completion_tokens") for record in records]
            completion = [int(value) for value in completion if value is not None]
            save_npy_atomic(path, matrix)
            write_json_atomic(meta_path(path), {
                "embedder": embedder.describe(),
                "caption_set": name,
                "records_fingerprint": fingerprint,
                "source_mtime": source_mtime,
                "count": int(matrix.shape[0]),
                "dimension": int(matrix.shape[1]),
                "embedder_text_tokens": token_stats(counts, embedder.text_token_limit),
                "caption_words_mean": round(float(np.mean([len(text.split()) for text in texts])), 2),
                "caption_completion_tokens_mean": (
                    round(float(np.mean(completion)), 2) if completion else None
                ),
                "seconds": round(seconds, 1),
                "versions": package_versions(*VERSIONS),
                "written_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })
            stats = token_stats(counts, embedder.text_token_limit)
            over = stats.get("fraction_over_limit")
            print(f"[{embedder.name}] {name}: wrote {matrix.shape}"
                  + (f", {over:.1%} of captions exceed the {stats['limit']}-token text limit"
                     if over is not None else ""), flush=True)
    return 1 if missing_sets else 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--embedder", required=True)
    parser.add_argument("--images", action="store_true", help="Embed the benchmark images.")
    parser.add_argument("--captions", action="store_true", help="Embed every complete caption set.")
    parser.add_argument("--captioners", nargs="+")
    parser.add_argument("--variants", nargs="+")
    parser.add_argument("--models-dir", type=Path)
    parser.add_argument("--device")
    parser.add_argument("--dataset-dir", type=Path)
    parser.add_argument("--image-dir", type=Path)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--text-batch-size", type=int, default=256)
    parser.add_argument("--workers", type=int, default=8, help="JPEG decode threads.")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if not (args.images or args.captions):
        args.images = args.captions = True
    return args


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    if args.embedder not in config["embedders"]:
        raise SystemExit(f"Unknown embedder {args.embedder!r}; known: {sorted(config['embedders'])}")
    layout = Layout(args.root)
    records = load_records(args.dataset_dir or default_dataset_dir(),
                           args.image_dir or default_image_dir(), config["datasets"],
                           check_files=args.images)
    fingerprint = records_fingerprint(records)
    embedder = load_embedder(args.embedder, config["embedders"][args.embedder],
                             models_dir=args.models_dir, device=args.device)
    print(f"[{embedder.name}] loaded on {embedder.device}, dim={embedder.dim}; "
          f"{len(records)} records; output under {layout.root}", flush=True)
    status = 0
    if args.images:
        run_images(args, embedder, layout, records, fingerprint)
    if args.captions:
        status |= run_captions(args, config, embedder, layout, records, fingerprint)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
