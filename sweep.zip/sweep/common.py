#!/usr/bin/env python3
"""Shared pieces of the sweep: config, canonical image list, output layout, atomic writes.

Every stage aligns its arrays to ONE canonical order: the sorted list of
(dataset, image_id) pairs read from the benchmark Parquet id columns. Image
vectors, caption vectors, and packed NPZ rows all follow that order, and a
SHA-256 fingerprint of it is stored next to every array so a mismatch is caught
instead of silently pairing the wrong caption with the wrong image.

Run as a script for the small shell helpers used by the job scripts:

    python3 sweep/common.py list captioners|embedders|variants|configs
    python3 sweep/common.py shell-captioner --captioner gemma3-4b
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shlex
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Iterator

SWEEP_DIR = Path(__file__).resolve().parent
REPO_ROOT = SWEEP_DIR.parent
DEFAULT_CONFIG = SWEEP_DIR / "sweep.json"

# Same id columns as scripts/extract_benchmark_images.py and edge_v3.
DATASET_ID_COLUMNS = {
    "cloudbench": "image_id",
    "commonobjectsbench": "image_id",
    "firebench": "image_id",
    "inquire-small": "inat24_image_id",
    "sagebench": "image_id",
}

# Same namespace as edge_v3/scripts/populate_edge_v3.py, so a point loaded from a
# sweep NPZ gets the same ID it had in the edge_v3 Qdrant collection.
POINT_ID_NAMESPACE = uuid.UUID("6f9d5c1e-3a7b-4e2f-9c88-0f5a1b2c3d4e")

PORTABLE_INDEX_VERSION = 1


# ------------------------------------------------------------------ config ---

def load_config(path: Path | str | None = None) -> dict[str, Any]:
    config_path = Path(path or os.environ.get("SWEEP_CONFIG") or DEFAULT_CONFIG)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    for dataset in config["datasets"]:
        if dataset not in DATASET_ID_COLUMNS:
            raise ValueError(f"Unknown dataset {dataset!r} in {config_path}")
    for name, fusion in config.get("fusions", {}).items():
        weights = [fusion.get("image", 0.0), fusion.get("caption", 0.0), fusion.get("bm25", 0.0)]
        if any(weight < 0 for weight in weights) or abs(sum(weights) - 1.0) > 1e-9:
            raise ValueError(f"Fusion {name!r} weights must be non-negative and sum to 1")
    config["_path"] = str(config_path)
    return config


def enabled(section: dict[str, Any]) -> dict[str, Any]:
    return {name: spec for name, spec in section.items() if spec.get("enabled", True)}


def pick(section: dict[str, Any], names: Iterable[str] | None, label: str) -> dict[str, Any]:
    """Selected entries by name, or every enabled entry when names is empty."""
    if not names:
        return enabled(section)
    chosen = {}
    for name in names:
        if name not in section:
            raise ValueError(f"Unknown {label} {name!r}; known: {sorted(section)}")
        chosen[name] = section[name]
    return chosen


def variant_max_tokens(config: dict[str, Any], variant: dict[str, Any]) -> int:
    """Hard token cap for a caption variant.

    Length is controlled by the cap, not the prompt (see edge_v3/README.md): the
    shared prompt over-asks, and target_words is converted with the measured
    tokens/word ratio plus a margin for the sentence-trim loss.
    """
    if "max_tokens" in variant:
        return int(variant["max_tokens"])
    captioning = config["captioning"]
    return round(
        int(variant["target_words"])
        * float(captioning["tokens_per_word"])
        * float(captioning["trim_margin"])
    )


def variant_prompt(config: dict[str, Any], variant: dict[str, Any]) -> str:
    return str(variant.get("prompt") or config["captioning"]["over_ask_prompt"])


def caption_set_name(captioner: str, variant: str) -> str:
    return f"{captioner}__{variant}"


def config_name(captioner: str, variant: str, embedder: str) -> str:
    return f"{captioner}__{variant}__{embedder}"


# ------------------------------------------------------------------ layout ---

class Layout:
    """Where every artifact of one sweep lives, under a single root directory."""

    def __init__(self, root: Path | str | None = None):
        self.root = Path(root or os.environ.get("SWEEP_ROOT") or SWEEP_DIR / "runs").resolve()

    @property
    def captions_dir(self) -> Path:
        return self.root / "captions"

    def caption_file(self, captioner: str, variant: str) -> Path:
        return self.captions_dir / f"{caption_set_name(captioner, variant)}.jsonl"

    def caption_errors(self, captioner: str, variant: str) -> Path:
        return self.captions_dir / f"{caption_set_name(captioner, variant)}.errors.jsonl"

    def caption_meta(self, captioner: str, variant: str) -> Path:
        return self.captions_dir / f"{caption_set_name(captioner, variant)}.meta.json"

    def vectors_dir(self, embedder: str) -> Path:
        return self.root / "vectors" / embedder

    def image_vectors(self, embedder: str) -> Path:
        return self.vectors_dir(embedder) / "images.npy"

    def caption_vectors(self, embedder: str, captioner: str, variant: str) -> Path:
        return self.vectors_dir(embedder) / f"captions__{caption_set_name(captioner, variant)}.npy"

    def query_vectors(self, embedder: str) -> Path:
        return self.vectors_dir(embedder) / "queries.npz"

    @property
    def npz_dir(self) -> Path:
        return self.root / "npz"

    def npz(self, captioner: str, variant: str, embedder: str) -> Path:
        return self.npz_dir / f"{config_name(captioner, variant, embedder)}.npz"

    @property
    def results_dir(self) -> Path:
        return self.root / "results"

    @property
    def db_dir(self) -> Path:
        return self.root / "db"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"


def meta_path(array_path: Path) -> Path:
    return array_path.with_suffix(".meta.json")


# ----------------------------------------------------------------- records ---

@dataclass(frozen=True)
class ImageRecord:
    dataset: str
    image_id: str
    image_path: Path

    @property
    def key(self) -> tuple[str, str]:
        return self.dataset, self.image_id

    @property
    def point_id(self) -> str:
        return str(uuid.uuid5(POINT_ID_NAMESPACE, f"{self.dataset}/{self.image_id}"))

    @property
    def relative_path(self) -> str:
        return str(PurePosixPath(self.dataset) / image_relative_path(self.image_id))


def image_relative_path(image_id: str) -> PurePosixPath:
    relative = PurePosixPath(image_id)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe image ID: {image_id!r}")
    return relative.with_suffix(".jpg")


def default_dataset_dir() -> Path:
    return Path(os.environ.get("DATASET_DIR") or REPO_ROOT / "benchmarking" / "datasets")


def default_image_dir() -> Path:
    return Path(os.environ.get("IMAGE_DIR") or REPO_ROOT / "benchmarking" / "image")


def load_records(
    dataset_dir: Path,
    image_dir: Path,
    datasets: list[str],
    *,
    check_files: bool = True,
) -> list[ImageRecord]:
    """Distinct (dataset, image_id) pairs, sorted. Reads ONLY the id column.

    The Parquet shards also carry annotation columns that the benchmark queries
    were written from; never reading them makes query leakage impossible by
    construction (same rule as edge_v3).
    """
    import pyarrow.parquet as pq

    records: dict[tuple[str, str], ImageRecord] = {}
    for dataset in datasets:
        id_column = DATASET_ID_COLUMNS[dataset]
        shards = sorted((dataset_dir / dataset / "data").glob("*.parquet"))
        if not shards:
            raise FileNotFoundError(f"No Parquet shards under {dataset_dir / dataset / 'data'}")
        for shard in shards:
            table = pq.read_table(shard, columns=[id_column])
            for raw_id in table.column(id_column).to_pylist():
                key = (dataset, str(raw_id))
                if key in records:
                    continue
                path = image_dir / dataset / Path(*image_relative_path(key[1]).parts)
                if check_files and not path.is_file():
                    raise FileNotFoundError(
                        f"Extracted image missing: {path} "
                        "(run scripts/extract_benchmark_images.py first)"
                    )
                records[key] = ImageRecord(dataset, key[1], path)
    return sorted(records.values(), key=lambda record: record.key)


def records_fingerprint(records: list[ImageRecord]) -> str:
    digest = hashlib.sha256()
    for record in records:
        digest.update(f"{record.dataset}\t{record.image_id}\n".encode("utf-8"))
    return digest.hexdigest()


# ------------------------------------------------------------------- files ---

def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                # A torn final line from a killed job is the only expected case.
                print(f"WARNING: skipping unreadable line {path}:{line_number}: {error}",
                      file=sys.stderr)


def load_caption_rows(path: Path) -> dict[tuple[str, str], dict[str, Any]]:
    rows: dict[tuple[str, str], dict[str, Any]] = {}
    for row in iter_jsonl(path):
        rows[(str(row["dataset"]), str(row["image_id"]))] = row
    return rows


def _atomic_target(path: Path) -> tuple[int, str]:
    path.parent.mkdir(parents=True, exist_ok=True)
    return tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)


def write_json_atomic(path: Path, payload: Any) -> None:
    handle, temp_name = _atomic_target(path)
    with os.fdopen(handle, "w", encoding="utf-8") as output:
        json.dump(payload, output, indent=2, ensure_ascii=False)
        output.write("\n")
    os.replace(temp_name, path)


def save_npy_atomic(path: Path, array: Any) -> None:
    import numpy as np

    handle, temp_name = _atomic_target(path)
    with os.fdopen(handle, "wb") as output:
        np.save(output, array)
    os.replace(temp_name, path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 2**20):
            digest.update(chunk)
    return digest.hexdigest()


def package_versions(*names: str) -> dict[str, str]:
    from importlib import metadata

    versions = {"python": sys.version.split()[0]}
    for name in names:
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            continue
    return versions


# ------------------------------------------------------------- shell helpers ---

def _main() -> int:
    parser = argparse.ArgumentParser(description="Shell helpers for the sweep job scripts.")
    parser.add_argument("--config", type=Path)
    sub = parser.add_subparsers(dest="command", required=True)
    listing = sub.add_parser("list", help="Print enabled names, one per line.")
    listing.add_argument("what", choices=["captioners", "embedders", "variants", "configs"])
    shell = sub.add_parser("shell-captioner", help="Emit bash assignments for one captioner.")
    shell.add_argument("--captioner", required=True)
    args = parser.parse_args()
    config = load_config(args.config)

    if args.command == "list":
        if args.what == "configs":
            for captioner in enabled(config["captioners"]):
                for variant in enabled(config["caption_variants"]):
                    for embedder in enabled(config["embedders"]):
                        print(config_name(captioner, variant, embedder))
        else:
            section = {"captioners": "captioners", "embedders": "embedders",
                       "variants": "caption_variants"}[args.what]
            for name in enabled(config[section]):
                print(name)
        return 0

    spec = config["captioners"][args.captioner]
    print(f"MODEL_DIR={shlex.quote(str(spec['model_dir']))}")
    print(f"SERVED_NAME={shlex.quote(str(spec['served_name']))}")
    print("VLLM_ARGS=(" + " ".join(shlex.quote(str(item)) for item in spec.get("vllm_args", [])) + ")")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
