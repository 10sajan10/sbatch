"""Caption clean-up, copied verbatim from edge_v3 (populate_edge_v3.py) so sweep
captions are post-processed exactly like the earlier runs."""

from __future__ import annotations


CAPTION_PREFIXES = (
    "this image shows", "this image depicts", "the image shows",
    "the image depicts", "here is a caption", "here is", "caption:",
)


def clean_caption(caption: str) -> str:
    text = " ".join(caption.split())
    lowered = text.lower()
    for prefix in CAPTION_PREFIXES:
        if lowered.startswith(prefix):
            text = text[len(prefix):].lstrip(" :,-").strip()
            break
    return text


def trim_to_last_sentence(text: str) -> str:
    """Cut a cap-truncated caption back to its last complete sentence.

    Only used when Ollama reports done_reason="length", i.e. the token cap cut
    the model off mid-thought. Bounded so a caption with no late punctuation
    isn't gutted -- better a slightly ragged tail than throwing away half the
    description.
    """
    end = max(text.rfind(". "), text.rfind(".\n"), text.rfind("! "), text.rfind("? "))
    if end == -1 and text.endswith((".", "!", "?")):
        return text
    if end > len(text) * 0.6:
        return text[: end + 1].strip()
    return text
